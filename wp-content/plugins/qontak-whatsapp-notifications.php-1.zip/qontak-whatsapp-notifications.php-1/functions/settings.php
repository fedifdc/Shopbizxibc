<?php

// Add settings menu
add_action('admin_menu', 'qontak_whatsapp_settings_menu');
function qontak_whatsapp_settings_menu() {
    add_options_page(
        'Qontak WhatsApp Settings',
        'Qontak WhatsApp',
        'manage_options',
        'qontak-whatsapp-settings',
        'qontak_whatsapp_settings_page'
    );
}

// Render the settings page
function qontak_whatsapp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Qontak WhatsApp Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('qontak_whatsapp_settings_group');
            do_settings_sections('qontak-whatsapp-settings'); // This renders the sections and fields
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'qontak_whatsapp_register_settings');

function qontak_whatsapp_register_settings() {
    // Existing settings
    register_setting('qontak_whatsapp_settings_group', 'qontak_api_token');
    register_setting('qontak_whatsapp_settings_group', 'qontak_channel_integration_id');
    register_setting('qontak_whatsapp_settings_group', 'qontak_admin_phone_number');
    register_setting('qontak_whatsapp_settings_group', 'qontak_default_message_template_id');

    // New settings for specific events
    register_setting('qontak_whatsapp_settings_group', 'qontak_register_template_id');
    register_setting('qontak_whatsapp_settings_group', 'qontak_order_thankyou_template_id');
    register_setting('qontak_whatsapp_settings_group', 'qontak_order_completed_template_id');

    // Add settings section
    add_settings_section('qontak_whatsapp_main_section', 'Main Settings', null, 'qontak-whatsapp-settings');

    // Existing settings fields
    add_settings_field('qontak_api_token', 'API Token', 'qontak_api_token_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
    add_settings_field('qontak_channel_integration_id', 'Channel Integration ID', 'qontak_channel_integration_id_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
    add_settings_field('qontak_admin_phone_number', 'Admin Phone Number', 'qontak_admin_phone_number_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
    add_settings_field('qontak_default_message_template_id', 'Default Message Template ID', 'qontak_default_message_template_id_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');

    // New settings fields for specific events
    add_settings_field('qontak_register_template_id', 'Register Message Template ID', 'qontak_register_template_id_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
    add_settings_field('qontak_order_thankyou_template_id', 'Order Thank You Message Template ID', 'qontak_order_thankyou_template_id_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
    add_settings_field('qontak_order_completed_template_id', 'Order Completed Message Template ID', 'qontak_order_completed_template_id_callback', 'qontak-whatsapp-settings', 'qontak_whatsapp_main_section');
}

// Existing callback functions
function qontak_api_token_callback() {
    $api_token = get_option('qontak_api_token');
    echo '<input type="text" name="qontak_api_token" value="' . esc_attr($api_token) . '" style="width:70%"/>';
}

function qontak_channel_integration_id_callback() {
    $channel_integration_id = get_option('qontak_channel_integration_id');
    echo '<input type="text" name="qontak_channel_integration_id" value="' . esc_attr($channel_integration_id) . '" style="width:70%"/>';
}

function qontak_admin_phone_number_callback() {
    $admin_phone_number = get_option('qontak_admin_phone_number');
    echo '<input type="text" name="qontak_admin_phone_number" value="' . esc_attr($admin_phone_number) . '" style="width:70%"/>';
}

function qontak_default_message_template_id_callback() {
    $default_message_template_id = get_option('qontak_default_message_template_id');
    echo '<input type="text" name="qontak_default_message_template_id" value="' . esc_attr($default_message_template_id) . '" style="width:70%"/>';
}

// New callback functions for specific events
function qontak_register_template_id_callback() {
    $register_template_id = get_option('qontak_register_template_id');
    echo '<input type="text" name="qontak_register_template_id" value="' . esc_attr($register_template_id) . '" style="width:70%"/>';
}

function qontak_order_thankyou_template_id_callback() {
    $order_thankyou_template_id = get_option('qontak_order_thankyou_template_id');
    echo '<input type="text" name="qontak_order_thankyou_template_id" value="' . esc_attr($order_thankyou_template_id) . '" style="width:70%"/>';
}

function qontak_order_completed_template_id_callback() {
    $order_completed_template_id = get_option('qontak_order_completed_template_id');
    echo '<input type="text" name="qontak_order_completed_template_id" value="' . esc_attr($order_completed_template_id) . '" style="width:70%"/>';
}