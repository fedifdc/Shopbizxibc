<?php
// CODE FOR HANDLING ORDER THANKYOU NOTIFICATION
add_action('wp_footer', 'qontak_send_notif_thankyou_ajax');
function qontak_send_notif_thankyou_ajax() {
	global $wp;
	// exit if we are not on the Thank You page
    if( !is_wc_endpoint_url( 'order-received' ) )
        return;

    $order_id  = absint( $wp->query_vars['order-received'] );
    ?>

		<script>
			jQuery(document).ready(function($) {
				$.ajax({
					url: "<?php echo admin_url('admin-ajax.php'); ?>",
					type: 'POST',
					data: "<?php echo 'action=send_whatsapp_notification_order_thankyou&order_id='.$order_id; ?>",
					success : function( data ){
						console.log( data );
					},
					error: function (error) {
						console.log(error);
					}
				});
			});
		</script>
    <?php 
}

// AJAX handler for sending WhatsApp notification
add_action('wp_ajax_send_whatsapp_notification_order_thankyou', 'send_whatsapp_notification_order_thankyou');
add_action('wp_ajax_nopriv_send_whatsapp_notification_order_thankyou', 'send_whatsapp_notification_order_thankyou');
function send_whatsapp_notification_order_thankyou() {
    if (!isset($_POST['order_id'])) {
        wp_send_json_error('Order ID not found.');
    }

    $order_id = sanitize_text_field($_POST['order_id']);
    $order = wc_get_order($order_id);

    if (!$order) {
        wp_send_json_error('Invalid order.');
    }

    // Get customer phone number from order
    $customer_phone_number = $order->get_billing_phone();
    $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
    $total = $order->get_total();

    // Get order items
    $items_list = array();
    foreach ($order->get_items() as $item) {
        $items_list[] = $item->get_name() . ' x ' . $item->get_quantity();
    }
    $details_pesanan = implode(", ", $items_list);

    // Prepare parameters for message
    $param = array(
        array('key' => '1', 'value' => 'order_number', 'value_text' => $order->get_order_number()),
        array('key' => '2', 'value' => 'customer_name', 'value_text' => $customer_name),
        array('key' => '3', 'value' => 'total', 'value_text' => $total),
        array('key' => '4', 'value' => 'detail_pesanan', 'value_text' => $details_pesanan),
    );

    // Send WhatsApp notification to customer
    $result = send_qontak_whatsapp_notification($customer_phone_number, $customer_name, $param, get_option('qontak_order_thankyou_template_id'));

    if (is_array($result) && isset($result['error'])) {
        wp_send_json_error($result);
    } else {
        wp_send_json_success($result); // Send real response body on success
    }
}


// =========================================================================
// Add AJAX request for sending WhatsApp notification after user registration
add_action('wp_footer', 'qontak_send_notif_user_register_ajax');
function qontak_send_notif_user_register_ajax() {
    if (!is_user_logged_in()) { // This script will be added only when the user is not logged in (i.e., during registration).
        ?>
        <script>
            jQuery(document).ready(function($) {
                // Detect if a new user has registered
                $(document).on('submit', 'form.register', function(event) {
                    // Send the AJAX request after form submission
                    $.ajax({
                        url: "<?php echo admin_url('admin-ajax.php'); ?>",
                        type: 'POST',
                        data: {
                            action: 'send_whatsapp_on_user_register'
                        },
                        success: function(data) {
                            // You can log the success message if necessary
                            console.log(data);
                        },
                        error: function(error) {
                            console.log(error);
                        }
                    });
                });
            });
        </script>
        <?php
    }
}

// Handle AJAX for sending WhatsApp notification after user registration
add_action('wp_ajax_send_whatsapp_on_user_register', 'send_whatsapp_on_user_register_ajax');
add_action('wp_ajax_nopriv_send_whatsapp_on_user_register', 'send_whatsapp_on_user_register_ajax');
function send_whatsapp_on_user_register_ajax() {
    // You can fetch the most recent registered user info.
    $recent_user = get_users(array(
        'orderby' => 'ID',
        'order'   => 'DESC',
        'number'  => 1,
    ));

    if (empty($recent_user)) {
        wp_send_json_error('No recently registered users found.');
    }

    $user = $recent_user[0];
    $user_id = $user->ID;
    $phone_number = get_user_meta($user_id, 'billing_phone', true); // Assuming phone is in billing_phone meta key

	$customer_name = trim($user->first_name . ' ' . $user->last_name);
    
    // Ensure customer_name is a valid string
    if (empty($customer_name)) {
        $customer_name = 'Customer'; // Fallback if no name is available
    }
    // Fallback for phone number
    if (empty($phone_number)) {
        $phone_number = get_option('qontak_admin_phone_number'); // Admin number as fallback
    }

    // Prepare parameters for WhatsApp message
    $param = array(
        array('key' => '1', 'value' => 'customer_name', 'value_text' => $customer_name),
        array('key' => '2', 'value' => 'user_email', 'value_text' => $user->user_email),
    );

    // Send WhatsApp notification using the function you already have
    $result = send_qontak_whatsapp_notification($phone_number, $customer_name, $param, get_option('qontak_register_template_id'));

    if (is_array($result) && isset($result['error'])) {
        wp_send_json_error($result['error']);
    } else {
        wp_send_json_success($result);
    }
}

// ==================== WA FOR ORDER COMPLETED========================


add_action('woocommerce_order_status_completed', 'send_wa_customer_order_notification', 10);

function send_wa_customer_order_notification($order_id) {
    // Get the order object
    $order = wc_get_order($order_id);
    if (!$order) {
        return; // Exit if order is not valid
    }

    // Get customer details
    $customer_phone_number = $order->get_billing_phone();
    $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
    $total = $order->get_total();

    // Get order items
    $items_list = array();
    foreach ($order->get_items() as $item) {
        $items_list[] = $item->get_name() . ' x ' . $item->get_quantity();
    }
    $details_pesanan = implode(", ", $items_list);

    // Prepare parameters for WhatsApp notification
    $param = array(
        array('key' => '1', 'value' => 'order_number', 'value_text' => $order->get_order_number()),
        array('key' => '2', 'value' => 'customer_name', 'value_text' => $customer_name),
        array('key' => '3', 'value' => 'total', 'value_text' => $total),
        array('key' => '4', 'value' => 'detail_pesanan', 'value_text' => $details_pesanan),
    );

    // Send WhatsApp notification
    $result = send_qontak_whatsapp_notification($customer_phone_number, $customer_name, $param, get_option('qontak_order_completed_template_id'));

    if (is_array($result) && isset($result['error'])) {
        error_log('Error sending WhatsApp notification for order ' . $order_id . ': ' . $result['error']);
    } else {
        error_log('WhatsApp notification sent successfully for order ' . $order_id);
    }
}



// WhatsApp notification function
function send_qontak_whatsapp_notification($phone_number, $to_name, $parameters = array(), $message_template_id = null) {
    $api_url = 'https://service-chat.qontak.com/api/open/v1/broadcasts/whatsapp/direct';

    $api_token = get_option('qontak_api_token');
    $channel_integration_id = get_option('qontak_channel_integration_id');

    if (!$message_template_id) {
        $message_template_id = get_option('qontak_default_message_template_id');
    }

    $body = json_encode(array(
        'to_number' => format_phone_number($phone_number),
        'to_name' => $to_name,
        'message_template_id' => $message_template_id,
        'channel_integration_id' => $channel_integration_id,
        'language' => array('code' => 'id'),
        'parameters' => array('body' => $parameters)
    ));

    $headers = array(
        'Content-Type' => 'application/json',
        'Authorization' => 'Bearer ' . $api_token
    );

    $response = wp_remote_post($api_url, array(
        'body' => $body,
        'headers' => $headers
    ));

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log('Qontak WhatsApp error: ' . $error_message);
        return array('error' => 'Error: ' . $error_message); // Return error
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);

    if ($response_code != 201) {
        error_log("Qontak WhatsApp error: Invalid response code: $response_code. Response Body: $response_body");
        return array('error' => 'Error: Invalid response code ' . $response_code . '. Response: ' . $response_body . 'Body' . $body); // Include response body in error
    }

    error_log('Qontak WhatsApp message sent successfully to ' . $phone_number);
    return json_decode($response_body, true); // Return the actual response body on success
}

function format_phone_number($phone_number) {
    // Remove any spaces or non-numeric characters just in case
    $phone_number = preg_replace('/\D/', '', $phone_number);

    // If the number starts with '0', replace it with '62'
    if (substr($phone_number, 0, 1) === '0') {
        $phone_number = '62' . substr($phone_number, 1);
    }

    return $phone_number;
}

