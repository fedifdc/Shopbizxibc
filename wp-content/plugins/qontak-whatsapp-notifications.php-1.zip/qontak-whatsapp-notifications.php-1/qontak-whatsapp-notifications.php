<?php
/*
Plugin Name: Qontak WhatsApp Notifications
Plugin URI: https://example.com/qontak-whatsapp-notifications
Description: A plugin to handle WhatsApp notifications using Qontak API.
Version: 1.0
Author: Novan NP
Author URI: https://novan-portfolio.netlify.app/
License: GPL2
*/

// Security check to ensure this file is not accessed directly
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once __DIR__ . '/functions/settings.php';
require_once __DIR__ . '/functions/send_notification.php';
