<?php

// Jadwalkan event cron jika belum ada

//register_activation_hook(__FILE__, 'convert_point_level_crone');
function convert_point_level_crone() {
    
    if (!wp_next_scheduled('convert_process_mycred_points')) {
        wp_schedule_event(strtotime('17:10:00'), 'daily', 'convert_process_mycred_points');
    }
}
  //block log external
function convert_point_level() {
    add_action('rest_api_init', function() {
        // Register order endpoint
        register_rest_route('shopbiz/v1', '/convert-point/', array(
            'methods' => 'GET',
            'callback' => 'process_mycred_points_function',
            //'permission_callback' => array($this, 'authenticate_request'),
        ));
    });
}

add_action('convert_process_mycred_points', 'process_mycred_points_function');
function process_mycred_points_function() {
    global $wpdb;
	$timestamps = getDynamicTimestamps();
    // Tanggal hari sebelumnya
    $yesterday_start = $timestamps['start_date'];//strtotime('yesterday midnight +7 hours');
    $yesterday_end = $timestamps['end_date'];//strtotime('today midnight +7 hours') - 1;

    // Ambil log `poin_external` dari tabel wp_mycreed_log untuk hari sebelumnya
    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT a.id, a.user_id, creds, website, c.user_partner_id
         FROM {$wpdb->prefix}myCRED_log a 
         LEFT JOIN {$wpdb->prefix}shopbiz_user_sync c ON a.user_id = c.user_id
         WHERE ctype = 'point_external_website' AND ref = 'reward' AND time >= %d AND time <= %d",
        $yesterday_start, $yesterday_end
    ));
    
    if ($logs === null) {
        error_log('Query Error: ' . $wpdb->last_error);
        //die(0);
    } 
// print("<pre>");
// print_r($logs);
// print("<br>");
// print_r($yesterday_start);
// print("<br>");

// print("</pre>");
// die(0);

    // Proses setiap log
    if ($logs) {
        foreach ($logs as $log) {
            $id = $log->id;
            $user_id = $log->user_id;
            $points = (float) $log->creds;
            $website = $log->website;
            $user_partner_id = $log->user_partner_id;

            // Ambil nilai poin_level dari usermeta
            $current_level_points = (float) get_user_meta($user_id, 'poin_level', true);
            $current_external_points = (float) get_user_meta($user_id, 'poin_external', true);

            add_point_level($user_id, $points, $website );

            // Kurangi poin_external
            substract_quota_from_crone($user_id, $points, $website );

            update_mycred_log_ctype($id, 'convert');
            
			$usermlm = get_user_meta($user_id,'shopbiz_user_id',true);
            // kirim poin ke mlm
			if($usermlm){
            	send_pv_to_mlm($user_id, $points);
			}
        }
    }
}

function add_point_level($user_id, $payout, $website){
    $point_type = "point_level";
    $log = "Given {$payout} from convert poin external from user {$user_id} member of {$website}";
    $reference = "convert point";
    mycred_add(
        $reference,
        $user_id,
        $payout,
        $log,
        '',
        array( 'ref_type' => 'post' ),
        $point_type
    );
}

function substract_quota_from_crone($user_id, $payout, $website){
    $point_type = 'point_external_website';
    $log = "Convert {$payout} to Point Level from user {$user_id} member of {$website}";
    $reference = "convert_point_external";
    mycred_add(
        $reference,
        $user_id,
        -$payout,
        $log,
        '',
        array( 'ref_type' => 'post' ),
        $point_type
    );
}

function convert_point_external_crone() {
    
    if (!wp_next_scheduled('convert_process_mycred_point_externals')) {
        wp_schedule_event(strtotime('17:01:00'), 'daily', 'convert_process_mycred_point_externals');
    }
}

function convert_process_mycred_point_externals(){
    global $wpdb;
    $point_type = 'point_external_pending';

    // Ambil log `poin_external` dari tabel wp_mycreed_log untuk hari sebelumnya
    $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT a.id, a.user_id, creds, website, c.user_id as user_partner_id
                FROM {$wpdb->prefix}myCRED_log a 
                LEFT JOIN {$wpdb->prefix}shopbiz_user_sync c ON a.user_id = c.user_id
                WHERE ctype = 'point_external_pending' AND ref='reward' order by id asc"));
     
     if($logs == null){
        error_log('Query Error: ' . $wpdb->last_error);
     }
    
    // die(0);
     if($logs){

        foreach ($logs as $log){
           
            $id = $log->id;
            $user_id = $log->user_id;
            $points = (float) $log->creds;
            $website = $log->website;
            $user_partner_id = $log->user_partner_id;
            $current_quota = (float) get_user_meta($user_partner_id, 'point_seller_internal', true);
          
            if($current_quota >= $points){
                // print("<pre>");
                // print_r($user_partner_id);
                // print_r($points);
                // print("</pre>");

                add_point_external_from_pending($user_id, $points, $website);

                substract_point_external_from_crone($id, $user_id, $points, $website);

                update_mycred_log_ctype($id, 'convert');

                send_pv_to_mlm($user_id, $points);
            }
        }
     }
}

function add_point_external_from_pending($user_id, $payout, $website){
    $point_type = 'point_external_website';
    $log = "Given {$payout} from convert poin external pending from user {$user_id} member of {$website}";
    $reference = "convert_point_external_pending";
    mycred_add(
        $reference,
        $user_id,
        $payout,
        $log,
        '',
        array( 'ref_type' => 'post' ),
        $point_type
    );
}

function substract_point_external_from_crone($id,$user_id, $payout, $website){
    $point_type = "point_external_pending";
    $log = "Convert {$payout} to Point External from user {$user_id} member of {$website}";
    $reference = "convert_point_to_external";
    mycred_add(
        $reference,
        $user_id,
        -$payout,
        $log,
        '',
        array( 'ref_type' => 'post' ),
        $point_type
    );
}

function substract_point_seller_internal_via_crone($user_id, $payout, $website){
    $point_type = "point_seller_internal";
    $log = "Debit {$payout} from Point External Pending form user {$user_id} member of {$website}";
    $reference = "debit_quota_from_pending";
    mycred_add(
        $reference,
        $user_id,
        -$payout,
        $log,
        '',
        array( 'ref_type' => 'post' ),
        $point_type
    );
}

function update_mycred_log_ctype($id, $ref) {
    global $wpdb;

    // Pastikan id valid
    if (empty($id) || !is_numeric($id)) {
        return new WP_Error('invalid_id', 'Invalid ID provided.');
    }

    // Nama tabel dengan prefix dinamis
    $table_name = $wpdb->prefix . 'myCRED_log';

    // Lakukan update menggunakan $wpdb
    $result = $wpdb->update(
        $table_name,            // Nama tabel  // Kondisi (berdasarkan ID)
        array('ref' => $ref ),   
        array('id' => $id),           // Kondisi (kolom => nilai)
        array('%s'),                  // Format untuk data baru ('ctype' adalah string)
        array('%d')           // Format data baru
    );

    print("<pre>");
    print_r('update log');
    print_r($result);
    print("</pre>");

    // Periksa apakah query berhasil
    if ($result === false) {
        print("<pre>");
        print_r('ini error');
        print_r($result);
        print("</pre>");
        return new WP_Error('db_update_error', 'Failed to update ctype.', $wpdb->last_error);
    }

    return $result; // Mengembalikan jumlah baris yang diperbarui
}

function send_pv_to_mlm($user_id, $point){
    $api_url = get_option('shopbiz_api_url') . '/user/update-pv';
    $api_data = array(
      'pv' => $point,
      'action' => 'add',
      'username' => get_userdata($user_id)->user_login
    );

    $api_data_json = json_encode($api_data);

    $response = wp_remote_post($api_url, array(
        'headers' => array(
            'Content-Type' => 'application/json',
            'secret_key' => get_option('shopbiz_api_token'),
            'prefix' => '1119',
        ),
        'body' => $api_data_json, 
        'method' => 'POST',
    )
    );

    // Handle the API response
    if (is_wp_error($response)) {
      error_log('API call failed: ' . $response->get_error_message());
    } else {
      $response_code = wp_remote_retrieve_response_code($response);
      $response_body = wp_remote_retrieve_body($response);
      if (200 !== $response_code) {
        error_log('API call returned an error: ' . $response_body);
      } else {
        $response_body = json_decode($response_body, true);
        print_r($response_body); 
      }
    }
}
function getCustomTimezoneTimestamp($timezone, $time = 'now') {
    // Buat objek DateTime berdasarkan waktu yang diberikan
    $date = new DateTime($time, new DateTimeZone($timezone));
    // Kembalikan timestamp dari objek DateTime
    return $date->getTimestamp();
}

function getDynamicTimestamps($timezone = 'Asia/Jakarta') {
    // Buat DateTime sekarang dengan timezone yang ditentukan
    //$now = new DateTime('now', new DateTimeZone($timezone));
	$now = new DateTime('now');
    
    // Dapatkan tanggal untuk start_date (awal hari ini di timezone Jakarta)
//     $start_date = new DateTime($now->format('Y-m-d 00:00:00'), new DateTimeZone($timezone));
    
//     // Dapatkan tanggal untuk end_date (akhir hari ini di timezone Jakarta)
//     $end_date = new DateTime($now->format('Y-m-d 23:59:59'), new DateTimeZone($timezone));
    
	 $start_date = new DateTime($now->format('Y-m-d 00:00:00'));
    
    // Dapatkan tanggal untuk end_date (akhir hari ini di timezone Jakarta)
    $end_date = new DateTime($now->format('Y-m-d 23:59:59'));
    // Konversi ke timestamp
    return [
        'start_date' => $start_date->getTimestamp(),
        'end_date' => $end_date->getTimestamp(),
    ];
}
