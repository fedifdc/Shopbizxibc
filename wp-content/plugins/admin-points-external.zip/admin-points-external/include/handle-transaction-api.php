<?php
//require __DIR__ . '/handle-api-request-class.php';
//require_once WP_PLUGIN_DIR .'/mycred/includes/classes/class.query-log.php';

class ShopbizPointExternalAPI extends HandleAPIRequest{

    public function transaction_point_external_api() {
        add_action('rest_api_init', function() {
            // Register order endpoint
            register_rest_route('shopbiz/v1', '/point-external/', array(
                'methods' => 'POST',
                'callback' => array($this, 'point_external_from_transaction'),
                'permission_callback' => array($this, 'authenticate_request'),
            ));
        });
    }

    public function point_external_from_transaction($request) {
        //point_external
        global $wpdb;
        //get param
        
        $body = json_decode(stripslashes($request->get_body()), true);
        $user_partner_id = $body['user_partner_id'];
        $poin_transaction = $body['poin_transaction'];
        $website = $request->get_header('website');
		$order_id = $body['order_id'];
        $table_name = $wpdb->prefix . 'shopbiz_user_sync';
        $curUser = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_partner_id = %s AND website = %s",
            $user_partner_id, $website
        ));
      
		$website_owner = $this->get_user_id($request);
		 
        if(!$curUser){
            return new WP_REST_Response( array(
                'status' => 'fail',
                'message' => "email ${email} tidak terdaftar di shopbiz.id"
            ), 422);
        }
        $user = get_user_by('id',$curUser->user_id);
        $partner_user_id = $this->get_user_id($request);
        $table_name = $wpdb->prefix . 'shopbiz_user_sync';
        // Masukkan ke input poin level
        $is_success = $this->insert_point($request,$user->id,$poin_transaction , $partner_user_id,$website, $website_owner, $order_id);
		    
        if($is_success){
            return new WP_REST_Response( array(
                'status' => 'success',
                'message' => "Berhasil Input Point dari account ${website} dengan account shopbiz.id"
            ), 200);
        } else {
            return new WP_REST_Response( array(
                'status' => 'fail',
                'message' => "error"
            ), 200);
        }  
    }

    //block log balance
    public function log_point_quota() {
        add_action('rest_api_init', function() {
            // Register order endpoint
            register_rest_route('shopbiz/v1', '/point-quota-log/', array(
                'methods' => 'GET',
                'callback' => array($this, 'poin_shopbiz_point_log'),
                'permission_callback' => array($this, 'authenticate_request'),
            ));
        });
    }

    public function poin_shopbiz_point_log($request){
        $body = json_decode(stripslashes($request->get_body()), true);
        $args = array(
            'number'    =>  -1,
            'order'     =>  'DESC',
            'ctype'     =>  "point_seller_internal",
            'user_id'    => $this->get_user_id($request)
        );
       $log =  new myCRED_Query_Log(  $args );
        if ( $log->have_entries() ) {
            //return  $log->display();
            return new WP_REST_Response( array(
                'status' => 'success',
                'data' => $log->results
            ), 200);
        } else {
            return new WP_REST_Response( array(
                'status' => 'success',
                'data' => []
            ), 200);
        }
    }

    //block log external
    public function log_point_external() {
        add_action('rest_api_init', function() {
            // Register order endpoint
            register_rest_route('shopbiz/v1', '/point-external-log/', array(
                'methods' => 'GET',
                'callback' => array($this, 'poin_shopbiz_external_log'),
                'permission_callback' => array($this, 'authenticate_request'),
            ));
        });
    }

    public function poin_shopbiz_external_log($request){
        $body = json_decode(stripslashes($request->get_body()), true);
        $args = array(
            'number'    =>  -1,
            'order'     =>  'DESC',
            'ctype'     =>  "point_external_website",
        );
       $log =  new myCRED_Query_Log(  $args );
        if ( $log->have_entries() ) {
            //return  $log->display();
            return new WP_REST_Response( array(
                'status' => 'success',
                'data' => $log->results
            ), 200);
        } else {
            return new WP_REST_Response( array(
                'status' => 'success',
                'data' => []
            ), 200);
        }
    }

        //block log pending
        public function log_point_pending() {
            add_action('rest_api_init', function() {
                // Register order endpoint
                register_rest_route('shopbiz/v1', '/point-pending-log/', array(
                    'methods' => 'GET',
                    'callback' => array($this, 'poin_shopbiz_pending_log'),
                    'permission_callback' => array($this, 'authenticate_request'),
                ));
            });
        }
    
        public function poin_shopbiz_pending_log($request){
            $body = json_decode(stripslashes($request->get_body()), true);
            $args = array(
                'number'    =>  -1,
                'order'     =>  'DESC',
                'ctype'     =>  "point_external_pending",
            );
           $log =  new myCRED_Query_Log(  $args );
            if ( $log->have_entries() ) {
                //return  $log->display();
                return new WP_REST_Response( array(
                    'status' => 'success',
                    'data' => $log->results
                ), 200);
            } else {
                return new WP_REST_Response( array(
                    'status' => 'success',
                    'data' => []
                ), 200);
            }
        }
}