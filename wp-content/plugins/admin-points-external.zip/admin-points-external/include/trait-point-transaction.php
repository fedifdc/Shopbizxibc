<?php

trait PointTransation {
   
}