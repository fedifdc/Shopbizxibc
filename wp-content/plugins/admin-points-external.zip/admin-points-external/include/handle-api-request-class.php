<?php
//require __DIR__ . '/trait-point-transaction.php';

abstract class HandleAPIRequest {

    protected $api_url;
    protected $api_key;
    protected $secret_key;
    protected $wpdb;
    protected $table_name;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_name = $wpdb->prefix . 'shopbiz_api_keys';
    }
    /**
     * Fungsi untuk mengautentikasi permintaan API
     */
    public function authenticate_request($request) {
        // Ambil API Key, Secret Key, dan Website dari header
        $api_key = $request->get_header('x-api-key');
        $secret_key = $request->get_header('x-secret-key');
        $website = $request->get_header('website');
        //$this->api_url = $api_url;
        $this->api_key = $api_key;
        $this->$secret_key = $secret_key;
        // Cek apakah ketiganya ada
        if (!$api_key || !$secret_key || !$website) {
            return new WP_Error('missing_keys', 'API Key, Secret Key, or Website is missing', array('status' => 401));
        }

        // Validasi di database
        $api_key_data = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM $this->table_name WHERE api_key = %s AND secret_key = %s AND website = %s",
            $api_key, $secret_key, $website
        ));

        // Jika valid, izinkan akses
        if ($api_key_data) {
            return 224;
        } else {
            return new WP_Error('invalid_keys', 'Invalid API Key or Secret Key', array('status' => 403));
        }
    }
    
    public function get_user_id($request) {
        // Ambil API Key, Secret Key, dan Website dari header
        $api_key = $request->get_header('x-api-key');
        $secret_key = $request->get_header('x-secret-key');
        $website = $request->get_header('website');

        // Cek apakah ketiganya ada
        if (!$api_key || !$secret_key || !$website) {
            return new WP_Error('missing_keys', 'API Key, Secret Key, or Website is missing', array('status' => 401));
        }

        // Validasi di database
        $api_key_data = $this->wpdb->get_row($this->wpdb->prepare(
            "SELECT * FROM $this->table_name WHERE api_key = %s AND secret_key = %s AND website = %s",
            $api_key, $secret_key, $website
        ));

        // Jika valid, izinkan akses
        if ($api_key_data) {
            return $api_key_data->user_id;
        } else {
            return new WP_Error('invalid_keys', 'Invalid API Key or Secret Key', array('status' => 403));
        }
    }

    public function get_quota($request, $partner_id){
        $quota = get_user_meta($partner_id, 'point_seller_internal', true);
        return $quota;
    }

    public function insert_point($request,$user_id,$point, $partner_id,$website, $website_owner, $order_id){
        //todo check quota point
       
        $quota =intval( $this->get_quota($request, $website_owner));
        $check_quota = intval($quota - intval($point));
		
        if($check_quota  >= 0) {
            $this->insert_point_external($user_id,$point, $partner_user_id,$website, $order_id);
            $this->substract_quota($website_owner,$point, $website, $user_id, $order_id);
            return true;
        } else {
            $this->insert_point_pending($user_id,$point,$partner_user_id,$website, $order_id);
            return true;
        }



        // todo insert point
    }



    public function insert_point_external($user_id,$point, $partner_id,$website, $order_id){
        $point_type = "point_external_website";
        $payout = $point;
        $buyer_id  = $user_id;
        if($payout == 0){
            return;
        }
        $reference = "reward";
        $log       = "Memberikan Poin sebesar {$payout} sebagai reward dari  www.{$website}";
		   
		mycred_add(
			$reference,
			$buyer_id,
			$payout,
			$log,
			$order_id,
			array( 'ref_type' => 'post' ),
			$point_type
		);
		
    }

    public function insert_point_pending($user_id,$point, $partner_id,$website){
        $point_type = 'point_external_pending';
        $payout = $point;
        $buyer_id  = $user_id;
        if($payout == 0){
            return;
        }
        $reference = "reward";
        $log       = "Poin sebesar{$payout} di tahan dari website www.{$website} karena Pont Seller nya kurang untuk memberikan Poin";
        
		mycred_add(
            $reference,
            $buyer_id,
            $payout,
            $log,
            $order_id,
            array( 'ref_type' => 'post' ),
            $point_type
        );
		
    }

    public function substract_quota($user_id, $payout, $website, $child_user, $order_id){
        $point_type = "point_seller_internal";
        $log = "Memberikan poin external sebesar {$payout} ke user {$child_user} member dari {$website}";
        $reference = "debit_quota";
		
        mycred_add(
            $reference,
            $user_id,
            -$payout,
            $log,
            $order_id,
            array( 'ref_type' => 'post' ),
            $point_type
        );
    }

    public function substract_point_external($user_id, $payout, $point_type, $website,$partner_user_id){
        $point_type = "mycred_default";
        $log = "Convert {$payout} from Point External member of {$website}";
        $reference = "convert-point-external";
        mycred_subtract(
            $reference,
            $buyer_id,
            $payout,
            $log,
            '',
            array( 'ref_type' => 'post' ),
            $point_type
        );
    }

    public function substract_point_pending($user_id, $payout, $point_type, $website,$partner_user_id){
        $point_type = "point_external_pending";
        $log = "Convert Pending Point {$payout}  from user {$user_id} member of {$website}";
        $reference = "convert-point-external-pending";
        mycred_subtract(
            $reference,
            $buyer_id,
            $payout,
            $log,
            '',
            array( 'ref_type' => 'post' ),
            $point_type
        );
    }


}
