<?php
/**
 * Plugin Name: Admin External Point Sync
 * Description: Plugin untuk sinkronisasi poin dengan website partner.
 * Version: 1.0
 * Author: Ruli Setiawan
 */

 // buat table yang berisi user id, api_key dan secretkey di wordpress database
 // buat fungsi untuk mengenerate api_key dan secret key di halaman my-account

 // Buat tabel untuk menyimpan user_id, api_key, dan secret_key saat plugin diaktifkan
 require_once __DIR__ . '/include/handle-account-api.php';
 require_once __DIR__ . '/include/handle-transaction-api.php';
 require __DIR__ . '/function/crone-point-level.php';
// defined('ABSPATH') || exit;

// require_once __DIR__ . '/functions/options.php';
// require_once __DIR__ . '/functions/registration.php';
// require_once __DIR__ . '/functions/upgrade.php';
// require_once __DIR__ . '/functions/order_complete.php';
// require_once __DIR__ . '/functions/commission_meta_box.php';
// require_once __DIR__ . '/functions/wpbv.php';
// require_once __DIR__ . '/templates/my-account.php';
 
 register_activation_hook(__FILE__, 'shopbiz_create_api_key_table');
 function shopbiz_create_api_key_table() {
     global $wpdb;
     $shopbiz_api_table = $wpdb->prefix . 'shopbiz_api_keys';
     $shopbiz_user_sync_table = $wpdb->prefix . 'shopbiz_user_sync';
     
     // Struktur SQL untuk membuat table
     $charset_collate = $wpdb->get_charset_collate();
 
     $shopbiz_api_keys = "CREATE TABLE IF NOT EXISTS $shopbiz_api_table (
         id BIGINT(20) NOT NULL AUTO_INCREMENT,
         user_id BIGINT(20) NOT NULL,
         api_key VARCHAR(64) NOT NULL,
         website  VARCHAR(200) NOT NULL,
         secret_key VARCHAR(64) NOT NULL,
         PRIMARY KEY (id),
         UNIQUE KEY website (website)
     ) $charset_collate;";
 
     $shopbiz_user_sync = "CREATE TABLE IF NOT EXISTS $shopbiz_user_sync_table (
         id BIGINT(20) NOT NULL AUTO_INCREMENT,
         user_id BIGINT(20) NOT NULL,
         user_partner_id BIGINT(20) NOT NULL,
         website  VARCHAR(200) NOT NULL,
         is_sync BOOLEAN NOT NULL DEFAULT 1,
         PRIMARY KEY (id)
     ) $charset_collate;";
 
     // Gunakan dbDelta untuk membuat table
     require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
     dbDelta($shopbiz_api_keys);
     dbDelta($shopbiz_user_sync);
 
 }


// Tambahkan form generate API Key dan Secret Key di halaman My Account
// Tambahkan shortcode untuk menampilkan form generate API Key di halaman khusus
add_shortcode('shopbiz_customer_api_key_page', 'shopbiz_display_generate_keys_form');

function shopbiz_display_generate_keys_form() {
    ob_start(); // Buffer output agar bisa dikembalikan sebagai hasil shortcode

    $user_id = get_current_user_id();

    if ($user_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'shopbiz_api_keys';

        // Cek apakah user sudah punya API Key
        $api_key_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE user_id = %d", $user_id));

        if ($api_key_data) {
            echo '<p>Your API Key: <strong>' . esc_html($api_key_data->api_key) . '</strong></p>';
            echo '<p>Your Secret Key: <strong>' . esc_html($api_key_data->secret_key) . '</strong></p>';
            echo '<p>Website: <strong>' . esc_html($api_key_data->website) . '</strong></p>';
        } else {
            echo '<form method="post">';
            echo '<label for="website">Website: </label>';
            echo '<input name="website" type="text" required>';
            echo '<br>';
            echo '<button type="submit" name="generate_api_keys" class="button">Generate API Key & Secret Key</button>';
            echo '</form>';
        }

        // Proses generate API Key jika tombol ditekan
        if (isset($_POST['generate_api_keys'])) {
            $website = sanitize_text_field($_POST['website']);
            shopbiz_generate_api_and_secret_key($user_id, $website);
            // Redirect to refresh page and display keys
            wp_redirect(get_permalink());
            exit;
        }
    } else {
        echo '<p>You need to be logged in to view this page.</p>';
    }

    return ob_get_clean(); // Return buffer content untuk shortcode
}

function shopbiz_generate_api_and_secret_key($user_id, $website) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'shopbiz_api_keys';

    // Generate API Key dan Secret Key acak
    $api_key = wp_generate_password(32, false); // 32 karakter alfanumerik
    $secret_key = wp_generate_password(64, true, true); // 64 karakter dengan simbol

    // Masukkan ke database
    $wpdb->insert($table_name, array(
        'user_id'    => $user_id,
        'api_key'    => $api_key,
        'website'    => $website,
        'secret_key' => $secret_key
    ));
}

add_action('rest_api_init', function() {
    add_filter('rest_pre_serve_request', function($value) {
        header('Access-Control-Allow-Origin: *'); // Atur domain asal, ganti * dengan domain spesifik jika perlu
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, x-api-key, x-secret-key, website'); // Tambahkan 'website'
        return $value;
    });
});

//Fungsi untuk mengambil data yang aman
// API LIST
$shopbiz_account = new ShopbizAccountPartnerAPI();

// get quota
$shopbiz_account->register_endpoints();

//sync account
$shopbiz_account->sync_account_partnert_endpoints();

//point transaction API

$shopbiz_point = new ShopbizPointExternalAPI();

$shopbiz_point->transaction_point_external_api();

$shopbiz_point->log_point_quota();
$shopbiz_point->log_point_external();
$shopbiz_point->log_point_pending();
convert_point_level();
convert_point_level_crone();
convert_point_external_crone();