<?php
// Add meta box for custom post type product
function commission_product_meta_box()
{
  add_meta_box(
    'shopbiz_commission_product_meta_box',
    'Komisi Produk',
    'render_commission_product_meta_box',
    'product',
    'normal',
    'default'
  );
}
add_action('add_meta_boxes', 'commission_product_meta_box');

// Render meta box content
function render_commission_product_meta_box($post)
{
  // Retrieve current values
  $BV = get_post_meta($post->ID, 'BV', true);

  // Output fields
  echo '<input type="text" id="BV" name="BV" value="' . esc_attr($BV) . '"> %';
  echo '<input type="hidden" name="shopbiz_product_meta_box_nonce" value="' . wp_create_nonce('shopbiz_save_product_meta_box') . '">';
}

// Save meta box data
function shopbiz_save_product_meta_box($post_id)
{
  // Check if nonce is set
  if (!isset($_POST['shopbiz_product_meta_box_nonce'])) {
    return;
  }

  // Verify nonce
  if (!wp_verify_nonce($_POST['shopbiz_product_meta_box_nonce'], 'shopbiz_save_product_meta_box')) {
    return;
  }

  // Check if autosave
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return;
  }

  // Check if user has permission to save data
  if (!current_user_can('edit_post', $post_id)) {
    return;
  }

  // Save meta box data
  if (isset($_POST['BV'])) {
    update_post_meta($post_id, 'BV', sanitize_text_field($_POST['BV']));
  }
}
add_action('save_post_product', 'shopbiz_save_product_meta_box');
