<?php
if (!defined('ABSPATH')) {
  exit;
}

// Handle AJAX post request
add_action('wp_ajax_shopbiz_upgrade', 'shopbiz_upgrade');
add_action('wp_ajax_nopriv_shopbiz_upgrade', 'shopbiz_upgrade');

function shopbiz_upgrade()
{
  $nonce = $_POST['nonce'];

  if (!wp_verify_nonce($nonce, 'shopbiz-upgrade-nonce')) {
    die('Nonce value cannot be verified.');
  }
  global $wpdb;

  $userdata = wp_get_current_user();

  $table_reg = $wpdb->prefix . 'shopbiz_registration';
  $query_reg = $wpdb->prepare("SELECT * FROM $table_reg WHERE customer_id = %d", $userdata->ID);
  $reg_data = $wpdb->get_row($query_reg);
  $phone = get_user_meta($userdata->ID, 'billing_phone', true);

  $table_referral = $wpdb->prefix . 'member';
  $query_referral = $wpdb->prepare("SELECT * FROM $table_referral WHERE idwp = %d", $userdata->ID);
  $referral_data = $wpdb->get_row($query_referral);
  $referral_id = get_user_meta($referral_data->id_referral, 'shopbiz_user_id', true);

  // Trigger API call on registration
  $api_url = get_option('shopbiz_api_url') . '/register';
  $api_data = array(
    // 'date_of_birth' => '2000-11-01',
    'email' => $userdata->user_email,
    'first_name' => $userdata->first_name,
    'gender' => 'M',
    'mobile' => $phone,
    'password' => $reg_data->password,
    'placement' => '',
    'position' => '',
    'pv' => intval(get_user_meta($userdata->ID, 'point_level', true)),
    'referralId' => $referral_id && !empty($referral_id) ? $referral_id : 1,
    'username' => $userdata->user_login,
    'ecomCustomerRefId' => $userdata->ID,
  );

  // Make the API call
  $response = wp_remote_post($api_url, array(
    'body' => $api_data,
    'headers' => array(
      'api-key' => get_option('shopbiz_api_token'),
    )
  ));

  // Handle the API response
  if (is_wp_error($response)) {
    // API call failed
    error_log('API call failed: ' . $response->get_error_message());
    $response = array(
      'success' => false,
      'message' => 'upgrade failed',
    );
    wp_send_json($response);
  } else {
    // API call successful
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);

    if ($response_code != 200 && $response_code != 201) {
      // API call returned an error
      error_log('API call returned an error: ' . $response_body);
      $response = array(
        'success' => false,
        'message' => 'Poin tidak mencukupi untuk upgrade',
      );
      wp_send_json($response);
    } else {
      $response_body = json_decode($response_body, true);
      add_user_meta($userdata->ID, 'shopbiz_user_id', $response_body['id']);

      $response = array(
        'success' => true,
        'message' => 'Selamat Anda telah terdaftar di ShopBiz.
          Silahkan <a href="https://member.shopbiz.id/" target="_blank">login ke aplikasi ShopBiz</a>
          menggunakan username dan password yang sama dengan akun ini.',
      );
      wp_send_json($response);
    }
  }
}
