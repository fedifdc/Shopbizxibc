<?php

/**
 * My Account - Points page
 */

if (!defined('ABSPATH')) {
  exit;
}

function point_level_endpoint()
{
  add_rewrite_endpoint('points', EP_ROOT | EP_PAGES);
  flush_rewrite_rules();
}
add_action('init', 'point_level_endpoint');
add_filter('woocommerce_get_query_vars', 'myaccount_custom_endpoint_query_var', 0);
function myaccount_custom_endpoint_query_var($query_vars)
{
  $query_vars['points'] = 'points';

  return $query_vars;
}

function point_level_menu_item($items)
{
  $items = array_slice($items, 0, count($items) - 1, true) +
    array('points' => __('Poin Level', 'points')) +
    array_slice($items, 1, null, true);

  return $items;
}
add_filter('woocommerce_account_menu_items', 'point_level_menu_item', 20);

function point_level_endpoint_content()
{
  $current_point = mycred_get_users_total(get_current_user_id(), 'point_level');
  $is_member = get_user_meta(get_current_user_id(), 'shopbiz_user_id', true);
?>
  <div class="ywpar-wrapper">
    <h2>My Points</h2>
    <div class="ywpar_myaccount_entry_info">
      <div class="ywpar_summary_badge">
        <span class="ywpar_entry_info_title">Points</span>
        <!-- <span class="ywpar_to_redeem_title">to redeem</span> -->
        <span class="points_collected"><?php echo do_shortcode('[mycred_my_balance type="point_level"]'); ?></span>
        <!-- <span class="ywpar_total_collected_title">total collected:<span>0</span></span> -->
      </div>
    </div>
    <?php if ($current_point >= 100 && !$is_member) : ?>
      <div id="countdown-container" style="margin-top: 20px">
        <div class="coutndown-head">
          <h4 class="subheading">Ayo buruan, upgrade akunmu sebelum:</h4>
        </div>

        <div id="countdown" data-stellar-ratio="0.5" data-state="loaded">
          <div id="timer">
            <div class="number-container day">
              <div class="number">00</div>
              <div class="text">Hari</div>
            </div>
            <div class="number-container hour">
              <div class="number">00</div>
              <div class="text">Jam</div>
            </div>
            <div class="number-container minute">
              <div class="number">00</div>
              <div class="text">Menit</div>
            </div>
            <div class="number-container second">
              <div class="number">00</div>
              <div class="text">Detik</div>
            </div>
          </div>
        </div>
      </div>
      <div id="upgrade" class="mt-4">
        <div class="cepatlakoo-message woocommerce-message" style="display: none;"></div>
        <button id="btn-upgrade" class="btn btn-primary">Upgrade ke MLM</button>
      </div>
    <?php elseif ($current_point >= 100 && $is_member) : ?>
      <div class="mt-4">
        <a href="https://member.shopbiz.id/" target="_blank" class="button">Login ke MLM</a>
      </div>
    <?php endif; ?>
    <div class="mt-4">
      <?php echo do_shortcode('[mycred_history type="point_level" user_id="current" show_user="0" number="20"]'); ?>
    </div>
  </div>
  <script>
    jQuery(document).ready(function($) {
      $('.ywpar-wrapper').on('click', '#btn-upgrade', function() {
        $('#btn-upgrade').attr('disabled', 'disabled').text('Mengirim...');
        var data = {
          action: 'shopbiz_upgrade',
          data: 'upgrade',
          nonce: '<?php echo wp_create_nonce('shopbiz-upgrade-nonce'); ?>'
        };
        $.post('<?php echo admin_url('admin-ajax.php'); ?>', data, function(response) {
          if (response.success) {
            $('#btn-upgrade').remove();
            $('#upgrade .woocommerce-message').addClass('woocommerce-info').html(response.message).show();
            $('#upgrade').append('<a href="https://member.shopbiz.id/" target="_blank" class="button">Login ke MLM</a>');
          } else {
            $('#btn-upgrade').removeAttr('disabled').text('Upgrade ke MLM');
            $('#upgrade .woocommerce-message').addClass('woocommerce-error').html(response.message).show();
          }
        });
      });

      <?php if ($current_point >= 100 && !$is_member) : ?>
        <?php
        $registered_date = new DateTime(get_userdata(get_current_user_id())->user_registered);
        $registered_date->modify('+90 days');
        ?>
        let countDownDate = new Date("<?php echo $registered_date->format('Y-m-d H:i:s'); ?>").getTime();
        let x = setInterval(function() {
          let now = new Date().getTime();
          let distance = countDownDate - now;
          let days = Math.floor(distance / (1000 * 60 * 60 * 24));
          let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
          let seconds = Math.floor((distance % (1000 * 60)) / 1000);

          $('#timer .day .number').html(days);
          $('#timer .hour .number').html(hours);
          $('#timer .minute .number').html(minutes);
          $('#timer .second .number').html(seconds);

          if (distance < 0) {
            clearInterval(x);
            $('#countdown').remove();
            $('#upgrade').remove();
            $('.countdown-head h4').html('Waktu upgrade telah berakhir');
          }
        }, 1000);
      <?php endif; ?>
    });
  </script>
<?php
}
add_action('woocommerce_account_points_endpoint', 'point_level_endpoint_content');
