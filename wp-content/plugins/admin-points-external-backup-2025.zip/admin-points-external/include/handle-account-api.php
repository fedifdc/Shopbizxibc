<?php
require __DIR__ . '/handle-api-request-class.php';


class ShopbizAccountPartnerAPI extends HandleAPIRequest{

    public function register_endpoints() {
        add_action('rest_api_init', function() {
            register_rest_route('shopbiz/v1', '/quota/', array(
                'methods' => 'GET',
                'callback' => array($this, 'get_quota_data'),
                'permission_callback' => array($this, 'authenticate_request'),
            ));
        });
    }

    public function get_quota_data($request) {
        $user_id = $this->get_user_id($request);
        $quota = get_user_meta($user_id, 'point_seller_internal', true);
        return new WP_REST_Response( array(
            'status' => 'success',
            'quota' => intval($quota)
        ), 200);
    }

    public function sync_account_partnert_endpoints() {
        add_action('rest_api_init', function() {
            register_rest_route('shopbiz/v1', '/sync-account/', array(
                'methods' => 'POST',
                'callback' => array($this, 'sync_user_account'),
                'permission_callback' => array($this, 'authenticate_request'),
            ));
        });
    }

    public function sync_user_account($request) {
        global $wpdb;
        $body = json_decode(stripslashes($request->get_body()), true);
        $email = html_entity_decode($body['shopbiz_email']);
        $user_partner_id = html_entity_decode($body['user_partner_id']);
        $website = html_entity_decode($request->get_header('website'));
       
        $user = get_user_by_email($email);
        $table_name = $wpdb->prefix . 'shopbiz_user_sync';
        
        $checkSync = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE user_id = %d AND user_partner_id = %d AND website = %s",
            $user->ID,
            $user_partner_id,
            $website
        ));
        
        if($checkSync){
            $wpdb->update($table_name, 
            array(
                'user_id'            => $user->id,
            ), array(
                'user_partner_id'    => $user_partner_id,
                'website'            => $website,
            )
            );

            return new WP_REST_Response( array(
                'status' => 'success',
                'message' => "Berhasil update Sync account {$website} dengan account shopbiz.id"
            ), 200);
        }
        if(!$user){
            return new WP_REST_Response( array(
                'status' => 'fail',
                'message' => "email {$email}  dan {$user} tidak terdaftar di shopbiz.id"
            ), 433);
        }
        $table_name = $wpdb->prefix . 'shopbiz_user_sync';
       
        $wpdb->insert($table_name, array(
            'user_id'            => $user->id,
            'user_partner_id'    => $user_partner_id,
            'website'            => $website,
            'is_sync'            => 1
        ));
        return new WP_REST_Response( array(
            'status' => 'success',
            'message' => "Berhasil Sync account {$website} dengan account shopbiz.id"
        ), 200);
    }
}