<?php
function hide_custom_menu_myaccount_for_guests() {
    if ( !is_user_logged_in() ) {
        ?>
        <style>
            .custom-menu-myaccount {
                display: none !important;
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'hide_custom_menu_myaccount_for_guests');


function custom_hide_navigation_and_expand_content() {
    ?>
    <style>
        /* Sembunyikan navigasi */
        .woocommerce-MyAccount-navigation {
            display: none;
        }

        /* Perluas konten menjadi 100% */
        .woocommerce-MyAccount-content {
            width: 100% !important;
            margin-left: 0; /* Hilangkan margin kiri yang mungkin ada */
        }
    </style>
    <?php
}

add_action('wp_head','custom_hide_navigation_and_expand_content');
