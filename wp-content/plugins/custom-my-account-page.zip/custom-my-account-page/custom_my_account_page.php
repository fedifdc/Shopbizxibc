<?php
/*
Plugin Name: Custom My Account Page
Description: A custom plugin to split my account shortcode.
Version: 1.0
Author: Novan Noviansyah P
*/


// Function to handle Orders content
function my_custom_orders_shortcode() {
    if (is_user_logged_in()) {
        ob_start();
		do_action('woocommerce_account_orders_endpoint');
        //do_action('woocommerce_order_affiliate_table'); // Correctly hooks into WooCommerce
        return ob_get_clean();
    } else {
        return 'Please log in to view your orders.';
    }
}
add_shortcode('my_custom_orders', 'my_custom_orders_shortcode');

// Function to handle Downloads content
// function my_custom_downloads_shortcode() {
//     if (is_user_logged_in()) {
//         ob_start();
//         do_action('woocommerce_account_downloads_endpoint'); // Correctly hooks into WooCommerce
//         return ob_get_clean();
//     } else {
//         return 'Please log in to view your downloads.';
//     }
// }
// add_shortcode('my_custom_downloads', 'my_custom_downloads_shortcode');

// Function to handle Addresses content
function my_custom_addresses_shortcode() {
    if (is_user_logged_in()) {
        ob_start();
        do_action('woocommerce_account_edit-address_endpoint'); // Correctly hooks into WooCommerce
        return ob_get_clean();
    } else {
        return 'Please log in to view your addresses.';
    }
}
add_shortcode('my_custom_addresses', 'my_custom_addresses_shortcode');

// Change WooCommerce Edit Address URL
// Register custom endpoint
function custom_add_edit_address_endpoint() {
    add_rewrite_endpoint( 'addresses', EP_ROOT | EP_PAGES );
}
add_action( 'init', 'custom_add_edit_address_endpoint' );

// Add query var for custom endpoint
function custom_query_vars( $vars ) {
    $vars[] = 'addresses';
    return $vars;
}
add_filter( 'query_vars', 'custom_query_vars' );

// Load custom template for address edit page
function custom_template_redirect() {
    global $wp_query;

    // Check if it's the custom endpoint
    if ( isset( $wp_query->query_vars['addresses'] ) && is_user_logged_in() ) {
        $address_type = $wp_query->query_vars['addresses'];
        // Check if address_type is valid
        if ( $address_type === 'edit-address' || $address_type === 'penagihan' || $address_type === 'pengiriman' ) {
            wc_get_template( 'myaccount/form-edit-address.php', array( 'load_address' => $address_type ) );
            exit;
        }
    }
}
add_action( 'template_redirect', 'custom_template_redirect' );
function custom_flush_rewrite_rules() {
    custom_add_edit_address_endpoint(); // Register custom endpoint
    flush_rewrite_rules(); // Flush rules
}
add_action( 'after_switch_theme', 'custom_flush_rewrite_rules' );



// Function to handle Account Details content
// function my_custom_account_details_shortcode() {
//     if (is_user_logged_in()) {
//         ob_start();
//         do_action('woocommerce_account_edit-account_endpoint'); // Correctly hooks into WooCommerce
//         return ob_get_clean();
//     } else {
//         return 'Please log in to view your account details.';
//     }
// }
// add_shortcode('my_custom_account_details', 'my_custom_account_details_shortcode');

// function custom_woocommerce_seller_support_shortcode() {
//     if (is_user_logged_in()) {
//         return do_shortcode('[woocommerce_my_account support-tickets]');
//     } else {
//         return '<p>You need to be logged in to view this content.</p>';
//     }
// }

// add_shortcode('my_custom_seller_support', 'custom_woocommerce_seller_support_shortcode');

// function custom_woocommerce_point_level_shortcode(){
// 	ob_start();
// 	do_action('woocommerce_account_points_endpoint');
// 	return ob_get_clean();
// }

// add_shortcode('point_level','custom_woocommerce_point_level_shortcode');

// // Add custom shortcode to display Dokan sellers list
function custom_dokan_seller_list_shortcode() {
    if (!function_exists('dokan_get_sellers')) {
        return '<div id="dokan-seller-listing-wrap" class="grid-view"><div class="seller-listing-content"><p class="dokan-error">Dokan plugin is not active!</p></div></div>';
    }

    $args = array(
        'post_type' => 'dokan_store',
        'posts_per_page' => -1, // Display all sellers
    );

    $query = new WP_Query($args);

    ob_start();
    ?>
    <div id="dokan-seller-listing-wrap" class="grid-view">
        <div class="seller-listing-content">
            <?php if ($query->have_posts()) : ?>
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <?php
                    $store_info = dokan()->vendor->get(get_the_ID());
                    ?>
                    <div class="seller-item">
                        <a href="<?php echo esc_url($store_info->get_store_url()); ?>">
                            <h3><?php echo esc_html($store_info->get_store_name()); ?></h3>
                        </a>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p class="dokan-error">No vendor found!</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('dokan_seller_list', 'custom_dokan_seller_list_shortcode');


// Add a shortcode to display support tickets similar to Dokan's layout
function custom_support_tickets_shortcode() {
    if ( ! is_user_logged_in() ) {
        return 'You need to be logged in to view this content.';
    }

    // Start output buffering
    ob_start();

    // HTML structure
    ?>
    <div class="dokan-support-customer-listing dokan-support-topic-wrapper">
        <ul class="dokan-support-topic-counts subsubsub">
            <li>
                <a href="<?php echo esc_url( add_query_arg( 'ticket_status', 'all', get_permalink() ) ); ?>">All Tickets (0) |</a>
            </li>
            <li class="active">
                <a href="<?php echo esc_url( add_query_arg( 'ticket_status', 'open', get_permalink() ) ); ?>">Open Tickets (0) |</a>
            </li>
            <li>
                <a href="<?php echo esc_url( add_query_arg( 'ticket_status', 'closed', get_permalink() ) ); ?>">Closed Tickets (0)</a>
            </li>
        </ul>
        <div class="dokan-support-topics-list">
            <?php
            // Fetch support tickets
            global $wpdb;
            $user_id = get_current_user_id();
            $status = isset($_GET['ticket_status']) ? sanitize_text_field($_GET['ticket_status']) : 'all';

            $query = "SELECT * FROM {$wpdb->prefix}dokan_support_tickets WHERE user_id = %d";
            if ($status != 'all') {
                $query .= $status == 'open' ? " AND status = 'open'" : " AND status = 'closed'";
            }
            $tickets = $wpdb->get_results( $wpdb->prepare($query, $user_id) );

            if ( $tickets ) {
                foreach ( $tickets as $ticket ) {
                    ?>
                    <div class="dokan-ticket-item">
                        <h4><a href="<?php echo esc_url( add_query_arg( 'ticket_id', $ticket->id, get_permalink() ) ); ?>"><?php echo esc_html($ticket->subject); ?></a></h4>
                        <p>Status: <?php echo esc_html($ticket->status); ?></p>
                    </div>
                    <?php
                }
            } else {
                echo '<div class="dokan-error">No tickets found!</div>';
            }
            ?>
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode('custom_support_tickets', 'custom_support_tickets_shortcode');
