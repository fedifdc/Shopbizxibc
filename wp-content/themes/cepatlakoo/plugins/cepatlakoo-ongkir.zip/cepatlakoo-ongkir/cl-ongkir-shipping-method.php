<?php
/**
 * @package cl_ongkir
 * @category Core
 * @author eezhal
 */

if ( !class_exists('CartWeight') ) {
	require_once 'include/cart-weight.php';
}

class Cl_Ongkir_Shipping_Method extends WC_Shipping_Method {
	/**
	 * Constructor for shipping class
	 *
	 * @access public
	 * @return void
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'cl_ongkir_shipping'; // Id for your shipping method. Should be uunique.
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = esc_html__( 'Cepatlakoo Ongkir', 'cl-ongkir' );  // Title shown in admin
		$this->method_description = esc_html__( 'WooCommerce add-on for indonesian local shipping with rajaongkir.com.', 'cl-ongkir' ); // Description shown in admin
		$this->supports           = array(
			'settings',
			'shipping-zones',
			'instance-settings',
			'instance-settings-modal',
		);

		$this->init();
		$this->init_form_fields();
	}

	/**
	 * Init your settings
	 *
	 * @access public
	 * @return void
	 */
	public function init() {
		global $woocommerce;
		global $cl_ongkir;

		// handle frontend cost request
		add_action( 'wp_ajax_get_costs', 'calculate_shipping' );
		add_action( 'wp_ajax_get_costs_pro', 'calculate_shipping' );

		// Save settings in admin if you have any defined
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );

		// This is part of the settings API. Loads settings you previously init.
		$this->init_settings();
		$this->init_instance_settings();

		// This is part of the settings API. Override the method to add your own settings
		// if ( strpos( $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']  , 'section=cl_ongkir_shipping' ) ) {
			$this->pro_error = isset($cl_ongkir->pro_status) ? $cl_ongkir->pro_status : false;
			$this->sta_error = isset($cl_ongkir->sta_status) ? $cl_ongkir->sta_status : false;
			$type = get_option('woocommerce_type_account');
			$cl_choose = get_option('cl_ongkir_choose_key');
			$check = (is_null($cl_ongkir)) ? false : $cl_ongkir->cl_ongkir_check_license();
			$lic_valid = (isset($check['cl']) ) ? $check['cl'] : false;
			$cl_valid = (isset($check['result']) ) ? $check['result'] : false;
			
			if ( $cl_choose == 'custom' && ( $type == 'starter' || $type == 'basic') && $this->sta_error != 0 ) {
				$this->valid = false;
			} else if ( $lic_valid && isset($cl_valid->status) && $cl_valid->status ) {
				$this->valid = true;
			} else if ( $type == 'pro' && $this->pro_error != 0 ) {
				$this->valid = false;
			} else if ( $type != 'pro' && $type != 'starter' && $type != 'basic' ) {
				$this->valid = false;
			} else {
				$this->valid = true;
			}

			$this->init_form_fields();
		// }

		$this->enabled = !isset($this->settings['enabled']) ? 'yes' : $this->settings['enabled'] ;
		$this->api_key = !isset($this->settings['rajaongkir_apikey']) ? null : $this->settings['rajaongkir_apikey'] ;
		$this->base_city = !isset($this->settings['base_city']) ? null : $this->settings['base_city'];
		$this->cl_last_name = !isset($this->settings['cl_last_name']) ? 'no' : $this->settings['cl_last_name'];
		$this->cl_company = !isset($this->settings['cl_company']) ? 'no' : $this->settings['cl_company'];
		$this->cl_address1 = !isset($this->settings['cl_address1']) ? 'no' : $this->settings['cl_address1'];
		$this->cl_address2 = !isset($this->settings['cl_address2']) ? 'no' : $this->settings['cl_address2'];
		$this->cl_email_option = !isset($this->settings['cl_email_option']) ? 'no' : $this->settings['cl_email_option'];
		$this->method = !isset($this->settings['method']) ? 'wp' : $this->settings['method'];

		// This can be added as an setting but for this example its forced.
		$this->title = esc_html__( 'Cepatlakoo Ongkir', 'cl-ongkir' );
	}

	public function process_admin_options(){
		parent::process_admin_options();

		if( $_POST['cl-choose-key'] == 'custom' && $this->settings['enabled'] == 'yes' && ( empty($this->settings['base_city']) || $this->settings['base_city'] == 0 || empty( $this->settings['rajaongkir_apikey'] ) ) ){
			add_action( 'admin_notices', 'cl_ongkir_setting_check' );
		}
		else{
			remove_action( 'admin_notices', 'cl_ongkir_setting_check' );
		}

		wp_cache_delete ( 'woocommerce_rajaongkir_api_key', 'options' );
		wp_cache_delete ( 'woocommerce_cl_ongkir_base_subdistrict', 'options' );
		wp_cache_delete ( 'woocommerce_type_account', 'options' );

		update_option( 'woocommerce_cl_ongkir_base_subdistrict', @$this->settings['base_city'] );
		update_option( 'woocommerce_rajaongkir_api_key', @$this->settings['rajaongkir_apikey'] );
		update_option( 'woocommerce_rajaongkir_method', @$this->settings['method'] );

		if( isset($_POST['instance_id']) && isset($_POST['data']['cl_ongkir_service']) ){
			update_option( 'cl_ongkir_services'.$_POST['instance_id'], $_POST['data']['cl_ongkir_service'] );
		}
		elseif( isset($_POST['cl_ongkir_service']) ){
			update_option( 'cl_ongkir_services', $_POST['cl_ongkir_service'] );
		}
		if( isset($_POST['cl-choose-key']) ){
			update_option( 'cl_ongkir_choose_key', $_POST['cl-choose-key'] );
		}

		require_once( plugin_dir_path( __FILE__ ) . 'include/cl-ongkir-shipping.php' );

		$cl_ongkir_shipping = Cl_Ongkir_Shipping::get_instance();
		$cl_ongkir_shipping->set_choose( $_POST['cl-choose-key'] );

		if( isset($_POST['cl-choose-key']) && $_POST['cl-choose-key'] == 'custom' ){
			update_option( 'woocommerce_type_account', $this->settings['type_ongkir'] );
			$cl_ongkir_shipping->set_api_key( $this->settings['rajaongkir_apikey'] );
			$cl_ongkir_shipping->set_server( $this->settings['type_ongkir'] );

			if ( ( $this->settings['type_ongkir'] == 'starter' || $this->settings['type_ongkir'] == 'basic') && $this->sta_error != 0 ) {
				$this->valid = false;
			} else if ( $this->settings['type_ongkir'] == 'pro' && $this->pro_error != 0 ) {
				$this->valid = false;
			} else if ( $this->settings['type_ongkir'] != 'pro' && $this->settings['type_ongkir'] != 'starter' && $this->settings['type_ongkir'] != 'basic') {
				$this->valid = false;
			} else {
				$this->valid = true;
			}
		}
		else{
			update_option( 'woocommerce_type_account', 'pro' );
		}
		$GLOBALS['cl_ongkir'] = $cl_ongkir_shipping;
	}

	/**
	 * Generate html settings form
	 *
	 * @return void
	 */
	public function admin_options() {
		global $cl_ongkir;

		$pro_color = 'color: #ff0000';
		$pro_status = esc_html__( 'Server offline', 'cl-ongkir' );
		$pro_class = 'dashicons-no';
		$sta_color = 'color: #ff0000';
		$sta_status = esc_html__( 'Server offline', 'cl-ongkir' );
		$sta_class = 'dashicons-no';

		if( isset($this->pro_error) ){
			if ( $this->pro_error == 0 ) {
				$pro_status = esc_html__( 'Server online', 'cl-ongkir' );
				$pro_color = 'color: #149911';
				$pro_class = 'dashicons-yes';
			}
			else if ( $this->pro_error == 3 ) {
				$pro_status = esc_html__( 'IP Website Anda Sepertinya Diblokir Oleh RajaOngkir', 'cl-ongkir' );
			}
			else{
				$pro_status = esc_html__( 'Server offline', 'cl-ongkir' );
			}
		}

		if( isset($this->sta_error) ){
			if ( $this->sta_error == 0 ) {
				$sta_status = esc_html__( 'Server online', 'cl-ongkir' );
				$sta_color = 'color: #149911';
				$sta_class = 'dashicons-yes';
			}
			else if ( $this->sta_error == 3 ) {
				$sta_status = esc_html__( 'IP Website Anda Sepertinya Diblokir Oleh RajaOngkir', 'cl-ongkir' );
			}
			else{
				$sta_status = esc_html__( 'Server offline', 'cl-ongkir' );
			}
		}
	?>
		<h2><?php esc_html_e('Cepatlakoo Ongkir Shipping', 'cepatlakoo'); ?></h2>

		<div class="cl-server-status">
			<table class="form-table">
				<tr valign="top">
					<th scope="row" class="titledesc"><label><?php esc_html_e( 'Status Server RajaOngkir', 'cl-ongkir' ); ?></label></td>
					<td class="forminp">
						<?php esc_html_e( 'Starter / Basic API:', 'cl-ongkir' ); ?>
						<span style="<?php echo $sta_color; ?>">
							<i class="dashicons <?php echo $sta_class; ?>"></i> <?php echo $sta_status; ?>
						</span>

						&nbsp; | &nbsp;

						<?php esc_html_e( 'Pro API:', 'cl-ongkir' ); ?>
						<span style="<?php echo $pro_color; ?>">
							<i class="dashicons <?php echo $pro_class; ?>"></i> <?php echo $pro_status; ?>
						</span>
					</td>
				</tr>
			</table>
		</div>

		<table class="form-table">
			<?php
			// $rajaongkir_api = get_option('woocommerce_rajaongkir_api_key');
			$rajaongkir_courrier = @$this->settings['courier'];
			$cl_base_city = @$this->settings['base_city'];
			$rajaongkir_type = get_option('woocommerce_type_account');
			$rajaongkir_choose = get_option('cl_ongkir_choose_key');
			$type = 'Starter / Basic';
			?>

			<?php if ( $rajaongkir_choose == 'custom' && $this->valid == false ) :
				if ( $rajaongkir_type == 'pro'){
					$type = 'Pro';
				}
				?>
				<div id="message" class="error fade">
					<p><strong>
					<?php esc_html_e( 'Tidak bisa terkoneksi dengan server '.$type.' RajaOngkir', 'cl-ongkir' ); ?>
					</strong></p>
				</div>
			<?php endif; ?>

			<?php if ( $rajaongkir_choose == 'custom' && empty($this->api_key) ) : ?>
				<div id="message" class="error fade">
					<p><strong>
						<?php esc_html_e( 'Harap masukkan API Key Raja Ongkir terlebih dahulu.', 'cl-ongkir' ); ?>
					</strong></p>
				</div>
			<?php endif; ?>

			<?php if ( $rajaongkir_choose == 'custom' && $this->enabled == 'yes' && $this->valid && empty($cl_base_city) && $cl_base_city == 0 ) : ?>
				<div id="message" class="error fade">
					<p><strong>
					<?php esc_html_e( 'Harap memilih kota pengiriman terlebih dahulu.', 'cl-ongkir' ); ?>
					</strong></p>
				</div>
			<?php endif; ?>

			<?php if ( $rajaongkir_choose == 'custom' && $this->valid == true && !empty($this->api_key) && ( !$cl_ongkir->check_valid_apikey($this->api_key)) ) : ?>
				<div id="message" class="error fade">
					<p><strong>
						<?php esc_html_e( 'ERROR: API key tidak ditemukan di database Raja Ongkir. Periksa Kesesuaian Tipe Akun Raja Ongkir dan API key', 'cl-ongkir' );?></strong>
					</p>
				</div>
			<?php endif;?>

			<?php $this->generate_settings_html(); ?>
		</table>
	<?php
	}

	/**
	 * Form for shipping method settings in admin
	 *
	 * @return void
	 */
	public function init_form_fields() {
		global $woocommerce;
		global $cl_ongkir;
		$rajaongkir_choose = get_option('cl_ongkir_choose_key');
		$req_city = '-';
		
		if( $this->valid && strpos($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']  , 'section=cl_ongkir_shipping') ){
			$req_city = $cl_ongkir->get_cities( $woocommerce->countries->get_base_state() );
			
			if($req_city == '-'){
				$req_city = esc_html__('Pastikan API Key dan tipe akun yang diinput sudah benar', 'cl-ongkir');
			}
		}
		else{
			$req_city = esc_html__('Pastikan API Key dan tipe akun yang diinput sudah benar', 'cl-ongkir');
		}

		$allowed_html = array(
			'a' => array(
		        'href' => array(),
		        'target' => array()
		    ),
		);

	    $this->form_fields = array(
	    	'enabled' => array(
			    'title'   => esc_html__( 'Aktifkan Ongkir', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'yes',
			    'label'   => esc_html__( 'Aktifkan metode pengiriman dengan Cepatlakoo Ongkir.', 'cl-ongkir' ),
			    'description' => esc_html__( 'Refresh halaman ini untuk menghapus cache.', 'cl-ongkir' ),
			),
			'method' => array(
			    'title'       => esc_html__( 'Metode Pengambilan Data', 'cl-ongkir' ),
			    'type'        => 'select',
			    'id'          => 'woocommerce_cl_ongkir_couriers',
				'multiple'	  => false,
				'default'	  => 'wp',
			    'description' => esc_html__( 'Metode pengambilan data yang ingin digunakan.', 'cl-ongkir' ),
			    'options'	  => array('wp' => esc_html__( 'WP Remote', 'cl-ongkir' ), 'get' => esc_html__( 'File Get Content', 'cl-ongkir' ))
			),
			'cl_ongkir_api' => array(
				'type' => 'cl_choose_key',
			),
			'rajaongkir_apikey' => array(
		        'title'       => esc_html__( 'API Key Raja Ongkir', 'cl-ongkir' ),
		        'type'        => 'text',
		        'class'       => 'cl-ongkir-custom-api',
		        'id'          => 'woocommerce_rajaongkir_api_key',
		        'description' => wp_kses( __(
			        				'Pastikan API Key yang diinput benar dan Simpan perubahan setelah memasukkan API agar Anda dapat memiliki basis kota pengiriman. <br>Tidak punya API Key Raja Ongkir? <a href="'. esc_url('http://rajaongkir.com/akun/daftar') .'" target="_blank">Daftar Sekarang</a>. ', 'cl-ongkir' ), $allowed_html
				),
			),
			'type_ongkir' => array(
		        'title'       => esc_html__( 'Tipe Akun RajaOngkir', 'cl-ongkir' ),
		        'type'        => 'select',
		        'id'          => 'woocommerce_rajaongkir_type_ongkir',
		        'class'       => 'chosen_select cl-ongkir-custom-api cl-ongkir-custom-api-type',
		        'description' => esc_html__( 'Tipe akun RajaOngkir yang Anda gunakan.', 'cl-ongkir' ),
		        'options'     => array(
					'starter'  => esc_html__( 'Starter', 'cl-ongkir' ),
					'basic'    => esc_html__( 'Basic', 'cl-ongkir' ),
					'pro'  	 => __( 'Pro', 'cl-ongkir' ),
				),
		    ),
			'base_city' => array(
		        'title'       => esc_html__( 'Lokasi Gudang Pengiriman Produk', 'cl-ongkir' ),
		        'type'        => 'select',
		        'id'          => 'woocommerce_cl_ongkir_base_city',
		        'class'       => 'chosen_select',
		        'description' => sprintf(__( 'Lokasi gudang tempat mengirim produk, hanya menampilkan daftar kota/kabupaten sesuai dengan provinsi yang dipilih pada seting alamat toko di %s. Pastikan API Key sudah dimasukkan agar daftar kota dapat muncul.', 'cl-ongkir' ), make_clickable(admin_url('admin.php?page=wc-settings&tab=general')) ),
		        'options'     => $req_city,
		        'default'	  => esc_html__( 'Pilih Kota Pengiriman', 'cl-ongkir' )
		    ),
			'show_weight' => array(
		        'title'       => esc_html__( 'Berat Minimum Produk ('.get_option('woocommerce_weight_unit').')', 'cl-ongkir' ),
		        'label'       => esc_html__( 'Berat minimum produk agar dapat melakukan perhitungan ongkir.', 'cl-ongkir' ),
		        'type'        => 'text',
		        'id'          => 'woocommerce_cl_ongkir_minimum_weight',
		        'description' => get_option(''),
		        'default'     => '1'
			),
			'cl_hide_estimate'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Estimasi Waktu Pengantaran', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan estimasi waktu pengantaran pada halaman checkout.', 'cl-ongkir' ),
			),
			'cl_single_subdistrict' => array(
		        'title'       => esc_html__( 'Hitung Ongkir Berdasarkan Kecamatan', 'cl-ongkir' ),
		        'label'       => esc_html__( 'Ya', 'cl-ongkir' ),
		        'type'        => 'checkbox',
		        'id'          => 'woocommerce_cl_ongkir_single_subdistrict',
		        'description' => esc_html__( 'Tampilkan hanya field kecamatan untuk menghitung ongkir, tanpa provinsi dan kota/kabupaten.', 'cl-ongkir' ),
		        'default'     => 'no'
			),
			'cl_last_name'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Field Last Name', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
				'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan field Last Name pada halaman checkout dan jadikan first name sebagai Full Name.', 'cl-ongkir' ),
			),
			'cl_company'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Field Company Name', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan field Company Name pada halaman checkout.', 'cl-ongkir' ),
			),
			'cl_country'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Field Country', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan field Country pada halaman checkout. PERINGATAN: Jangan aktifkan fitur ini jika Anda juga melayani pengiriman ke negara selain Indonesia karena akan muncul error dari plugin Cepatlakoo Ongkir.', 'cl-ongkir' ),
			),
			'cl_address1'	=> array(
			    'title'   => esc_html__( 'Field Address 1 Menggunakan textarea', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Membuat field Address Line 1 menggunakan textarea yang memiliki jumlah baris lebih banyak.', 'cl-ongkir' ),
			),
			'cl_address2'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Field Address Line 2', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan field Address Baris Kedua pada halaman checkout.', 'cl-ongkir' ),
			),
			'cl_email_option'	=> array(
			    'title'   => esc_html__( 'Matikan required di field email', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Matikan required di field email pada halaman checkout. Jadi pengunjung bisa order tanpa harus mengisi email', 'cl-ongkir' ),
			),
			'cl_notes'	=> array(
			    'title'   => esc_html__( 'Sembunyikan Field Order Notes', 'cl-ongkir' ),
			    'type'    => 'checkbox',
			    'default' => 'no',
			    'label'   => esc_html__( 'Ya', 'cl-ongkir' ),
			    'description' => esc_html__( 'Sembunyikan Field Order Notes pada halaman checkout.', 'cl-ongkir' ),
			),
		);

		if ( 'ID' !== WC()->countries->get_base_country() ) {
			$settings = array(
				'error' => array(
					'title'       => __( 'Error', 'cl-ongkir' ),
					'type'        => 'title',
					'description' => __( 'Plugin ini hanya dapat digunakan jika alamat toko berada di Indonesia.', 'cl-ongkir' ). '<br><a href="'.admin_url('admin.php?page=wc-settings&tab=general').'" class="button-primary">'. __('Ubah Alamat Toko', 'cl-ongkir').'</a>',
				),
			);
			$this->instance_form_fields = $settings;
			return;
		}

		if ( ($rajaongkir_choose == 'custom' && empty($this->api_key)) || empty($rajaongkir_choose) ) {
			$settings = array(
				'error' => array(
					'title'       => __( 'Error', 'cl-ongkir' ),
					'type'        => 'title',
					'description' => __( 'Anda belum memilih opsi metode API Raja Ongkir pada halaman seting CL Ongkir.', 'cl-ongkir' ). ' <a href="'.admin_url('admin.php?page=wc-settings&tab=shipping&section=cl_ongkir_shipping').'" class="button-primary">'. __('Perbaiki Sekarang', 'cl-ongkir').'</a>',
				),
			);
			$this->instance_form_fields = $settings;
			return;
		}

		$this->instance_form_fields = array(
			'enable_service' => array(
				'type' => 'cl_enable_service_ajax',
			)
		);
	}

	/**
	 * Calculate shipping cost in checkout form.
	 *
	 * @access public
	 * @param mixed $package
	 * @return void
	 */
	public function calculate_shipping( $package = array() ) {
		global $woocommerce;
		global $cl_ongkir;
		global $post;
		
		if( !is_cart() && !is_checkout() && did_action('wp_ajax_cl_order_form_ongkir') == 0 ){
			return false;
		}

		$current_shipping_city = $package['destination']['city'];
		$current_shipping_subdistrict = '';
		
		if ( !empty($package['destination']['cl_ongkir_code']) && !empty($package['destination']['cl_ongkir_type']) ) {
			$type_ongkir = $package['destination']['cl_ongkir_type'];
			$current_shipping_subdistrict = $package['destination']['cl_ongkir_code'];
		} else {
			$type_ongkir = 'city';
			$current_shipping_subdistrict = $package['destination']['city'];
		}
		
		// var_dump($package['destination']); exit();
		$current_cart_weight = $this->get_cart_weight(true); // in gram
		$height = 10;
		$width = 10;
		$length = 10;

		$couriers = array();
		$raw_couriers = get_option('cl_ongkir_services'.$this->instance_id);
		if( !empty($raw_couriers) ){
			foreach( $raw_couriers as $key_c => $raw_c ){
				if( $key_c == 'J&T' )
					$key_c = 'jnt';
				if( $key_c == 'additional' || $key_c == 'free' )
					continue;
					
				$couriers[] = $key_c;
			}
		}
		else{
			$couriers[] = 'jne';
		}

		$shipping_couriers = array(); // results
		$type_acc = ( get_option( 'cl_ongkir_choose_key') == 'custom' ) ? get_option('woocommerce_type_account') : 'pro';

		if ( $couriers == null || ( $type_acc == 'starter' && in_array( "all", $couriers ) ) ) {
			$couriers = ['jne', 'tiki', 'pos'];
		} elseif ( in_array( "all", $couriers ) && $type_acc == 'basic' ) {
			$couriers = ['jne', 'tiki', 'pos', 'pcp', 'esl', 'rpx'];
		} elseif ( in_array( "all", $couriers ) && $type_acc == 'pro' ) {
			$couriers = 'jne:pos:tiki:rpx:esl:pcp:pandu:wahana:sicepat:jnt:pahala:cahaya:sap:indah:dse:slis:ncs:star:first:ninja:lion:idl:sentral:ide:anteraja:rex:jtl';
		} elseif ( $type_acc == 'pro' ) {
			$couriers = implode( ':', $couriers );
			// $couriers = ['jne:pos:tiki:rpx:esl:pcp:pandu:wahana:sicepat:jnt:pahala:cahaya:sap:indah:dse:slis:ncs:star' ];
		}

		$valid = false;
		if( isset($raw_couriers['free']['status']) && $raw_couriers['free']['status'] == 1 ){
			$requires = isset($raw_couriers['free']['type']) ? $raw_couriers['free']['type'] : 'none';
			$min_amount = isset($raw_couriers['free']['min_amount']) ? (int) filter_var($raw_couriers['free']['min_amount'], FILTER_SANITIZE_NUMBER_INT) : 0;
			$ignore_discounts = isset($raw_couriers['free']['ignore']) ? $raw_couriers['free']['ignore'] : 'no';

			$has_coupon         = false;
			$has_met_min_amount = false;

			if ( in_array( $requires, array( 'coupon', 'either', 'both' ), true ) ) {
				$coupons = WC()->cart->get_coupons();

				if ( $coupons ) {
					foreach ( $coupons as $code => $coupon ) {
						if ( $coupon->is_valid() && $coupon->get_free_shipping() ) {
							$has_coupon = true;
							break;
						}
					}
				}
			}

			if ( in_array( $requires, array( 'min_amount', 'either', 'both' ), true ) ) {
				$total = WC()->cart->get_displayed_subtotal();

				if ( WC()->cart->display_prices_including_tax() ) {
					$total = $total - WC()->cart->get_discount_tax();
				}

				if ( 'no' === $ignore_discounts ) {
					$total = $total - WC()->cart->get_discount_total();
				}

				$total = $this->round( $total, wc_get_price_decimals() );

				if ( $total >= $min_amount ) {
					$has_met_min_amount = true;
				}
			}

			switch ( $requires ) {
				case 'min_amount':
					$valid = $has_met_min_amount;
					break;
				case 'coupon':
					$valid = $has_coupon;
					break;
				case 'both':
					$valid = $has_met_min_amount && $has_coupon;
					break;
				case 'either':
					$valid = $has_met_min_amount || $has_coupon;
					break;
				default:
					$valid = true;
					break;
			}

			if( $valid ){
				$this->add_rate(
					array(
						'id' => $this->id . "_cl_free_ongkir",
						'label' => esc_html__( 'Gratis Ongkir', 'cl-ongkir' ),
						'cost' => 0,
						'calc_tax' => 'per_item',
					)
				);
			}
		}

		if( ( !isset($raw_couriers['free']['hide_other']) || (isset($raw_couriers['free']['hide_other']) && $raw_couriers['free']['hide_other'] != 1) || !$valid) ){
			if($current_cart_weight > 50000){
				if($type_acc == 'pro'){
					$couriers = explode(":",$couriers);
					$couriers = array_diff($couriers, ['pos']);
					$couriers = implode( ':', $couriers );
				}
				elseif(is_array($couriers) && in_array('pos', $couriers )){
					$couriers = array_diff($couriers, ['pos']);
				}
			}
	
			if ( get_option('woocommerce_type_account') == 'pro' || get_option('cl_ongkir_choose_key') != 'custom' ) {
				$result = $this->get_available_shippings_pro(
					$type_ongkir,
					$current_shipping_subdistrict,
					$current_cart_weight,
					$couriers,
					$height,
					$width,
					$length
				);
	
				$shipping_couriers = $result;
			} else {
				foreach ( $couriers as $courier ) {
					$result = $this->get_available_shippings_starter_basic(
						$current_shipping_city,
						$current_cart_weight,
						$courier
					);
					
					if( !is_null($result) ){
						$shipping_couriers[] = $result[0];
					}
				}
			}
	
			if ( $shipping_couriers != '-' && !empty($shipping_couriers) ) {
				$servs = array();
				$opts = get_option('cl_ongkir_services'.$this->instance_id);
				
				foreach ( @$shipping_couriers as $courier ) {
					if ( isset( $courier['code'] ) ) {
						$servs[$courier['code']] = ( isset($opts[$courier['code']]) && !empty($opts[$courier['code']] )) ? $opts[$courier['code']] : false;
					}
	
					if ( is_array( $courier ) || is_object( $courier ) ) {
						foreach ( $courier['costs'] as $item ) {
							foreach ( $item['cost'] as $cost ) {
								if ( ( isset($servs[$courier['code']][$item['service']] ) && $servs[$courier['code']][$item['service']] === 'on') ||
								( isset($servs[$courier['code']]) && $servs[$courier['code']] === 'all' ) ||
								($opts == false && ($item['service'] == 'REG' || $item['service'] == 'YES' || $item['service'] == 'CTC' || $item['service'] == 'CTCYES') ) ||
								($item['service'] == 'CTC' && isset($servs['jne']['REG'] )) ||
								($item['service'] == 'CTCYES' && isset($servs['jne']['YES'] )) ) {
									if ( $cost['value'] ) {
										if( isset($this->settings['cl_hide_estimate']) && $this->settings['cl_hide_estimate'] == 'yes' ){
											$label = $courier['name'] . " - " . $item['description'];
										}
										else{
											$label = $courier['name'] . " - " . $item['description'] . " " . __( 'Estimasi:', 'cl-ongkir' ) .  $cost['etd'] . " " . __( 'hari', 'cl-ongkir' );
										}
	
										if( isset($opts['additional']['type']) && $opts['additional']['type'] === 'fixed' ){
											$final_cost = (int)$cost['value'] + (int) filter_var($opts['additional']['fixed'], FILTER_SANITIZE_NUMBER_INT);
										}
										else if( isset($opts['additional']['type']) && $opts['additional']['type'] === 'percent' ){
											$final_cost = (int)$cost['value'] + ( (int)$cost['value'] * (int) filter_var($opts['additional']['percent'], FILTER_SANITIZE_NUMBER_INT) / 100 );
										}
										else{
											$final_cost = (int)$cost['value'];
										}
										
										$this->add_rate(
											array(
												'id' => $this->id . "_" . $courier['name'] . "_" . $item['service'] ,
												'label' => $label,
												'cost' => $final_cost,
												'calc_tax' => 'per_item',
											)
										);
										if ( is_cart() )
											return;
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Get current cart weight.
	 *
	 * @param bool $to_gram
	 * @return int
	 */
	private function get_cart_weight($to_gram = false) {
		global $woocommerce;

		$current_cart_weight = $woocommerce->cart->cart_contents_weight;
		$minimum_weight = get_option('woocommerce_cl_ongkir_minimum_weight');

		// if woocommerce_cl_ongkir_minimum_weight value not set
		if ( ! $minimum_weight ) {
			$minimum_weight = 1;
		}

		if ( $current_cart_weight < $minimum_weight ) {
			$current_cart_weight = $minimum_weight;
		}

		// if flag is true, convert to gram and return it
		if ( $to_gram ) {
			$weight_unit = get_option('woocommerce_weight_unit');

			return CartWeight::toGram($current_cart_weight, $weight_unit);
		}

		return $current_cart_weight;
	}

	/**
	 * Get available shippings based on store city and customer city
	 *
	 * @param int $shipping_city
	 * @param int $cart_weight
	 * @param string $courier
	 * @return array
	 */
	private function get_available_shippings_starter_basic( $shipping_city, $cart_weight, $courier ) {
		if ( $origin_city = $this->settings['base_city'] ) {
			global $cl_ongkir;

			return $cl_ongkir->get_costs(
				$origin_city,
				$shipping_city,
				$cart_weight,
				$courier
			);
		}
	}

	/**
	 * Get available shippings based on store city and customer city
	 *
	 * @param int $shipping_city
	 * @param int $cart_weight
	 * @param string $courier
	 * @return array
	 */
	private function get_available_shippings_pro( $type_ongkir, $shipping_subdistrict, $cart_weight, $courier, $height, $width, $length ) {
		$origin_city = null;

		if ( ! $origin_city ) {
			$origin_city = $this->settings['base_city'];
			global $cl_ongkir;

			return $cl_ongkir->get_costs_pro(
				$type_ongkir,
				$origin_city,
				$shipping_subdistrict,
				$cart_weight,
				$courier,
				$height,
      			$width,
      			$length
			);
		} else {
			echo esc_html( 'Harap cek kembali pengaturan Cepatlakoo Ongkir Anda', 'cl-ongkir' );
		}

	}

	/**
	 * Get Courrier
	 *
	 * @param string $type_ongkir
	 * @return array
	 */
	private function get_courrier( $type_ongkir ) {
		$newapi = $this->get_option('rajaongkir_apikey');
		$newtype = $this->get_option('type_ongkir');
		wp_cache_delete ( 'woocommerce_rajaongkir_api_key', 'options' );
		wp_cache_delete ( 'woocommerce_type_account', 'options' );
		update_option( 'woocommerce_type_account', $newtype );
		update_option( 'woocommerce_rajaongkir_api_key', $newapi );

		$list_ekspedisi = array(
	    	'all' => 'All',
	    	'jne' => 'Jalur Nugraha Ekakurir (JNE)',
	    	'pos' => 'POS Indonesia (POS)',
	    	'tiki'=> 'Citra Van Titipan Kilat (TIKI)',
	    	'pcp' => 'Priority Cargo and Package (PCP)',
	    	'esl' => 'Eka Sari Lorena (ESL)',
	    	'rpx' => 'RPX Holding (RPX)',
	    	'pandu'=> 'Pandu Logistics (PANDU)',
	    	'wahana'=> 'Wahana Prestasi Logistik (WAHANA)',
	    	'sicepat'=> 'SiCepat Express (SICEPAT)',
	    	'jnt'=> 'J&T Express (J&T)',
	    	'pahala'=> 'Pahala Kencana Express (PAHALA)',
	    	'cahaya'=> 'Cahaya Logistik (CAHAYA)',
	    	'sap'=> 'SAP Express (SAP)',
	    	'indah'=> 'Indah Logistic (INDAH)',
	    	'slis'=> 'Solusi Ekspres (SLIS)',
			// 'expedito'=> 'Expedito*',
	    	'dse'=> '21 Express (DSE)',
			'first'=> 'First Logistics (FIRST)',
			'ncs' => 'Nusantara Card Semesta (NCS)',
			'star' => 'Star Cargo (STAR)',
			'ninja' => 'Ninja Xpress',
			'lion' => 'Lion Parcel (LION)',
			'idl' => 'IDL Cargo (IDL)',
	    	'sentral'=> 'Sentral Cargo (SENTRAL)',
	    	'ide'=> 'ID Express (IDE)',
	    	'anteraja'=> 'AnterAja (ANTERAJA)',
	    	'rex'=> 'Royal Express Indonesia (REX)',
			'jtl'=>'JTL Express'
	    );

		if ( $type_ongkir == 'starter' ) {
			$list = array_slice($list_ekspedisi, 0, 4);
		} elseif ( $type_ongkir == 'basic' ) {
			$list = array_slice($list_ekspedisi, 0, 7);
		} elseif ( $type_ongkir == 'pro' ) {
			$list = $list_ekspedisi;
		} else {
			$list = array_slice($list_ekspedisi, 0, 3);
		}
		return $list;
	}

	/**
	 * Form for service settings in admin
	 *
	 * @return void
	 */
	public function generate_cl_enable_service_html() {
		ob_start();
		?>
		<tr class="cl-service-parent">
		<th scope="row" class="titledesc"><?php esc_html_e( 'Pilih Service Kurir', 'cl-ongkir' ); ?></th>
		<td style="height: 100px;">
			<?php $cl_services = get_option('cl_ongkir_services'); ?>
			<input type="hidden" name="cl_ongkir_service][esl]" value="all">
			<input type="hidden" name="cl_ongkir_service][pandu]" value="all">
			<input type="hidden" name="cl_ongkir_service][wahana]" value="all">
			<input type="hidden" name="cl_ongkir_service][J&T]" value="all">
			<input type="hidden" name="cl_ongkir_service][cahaya]" value="all">
			<input type="hidden" name="cl_ongkir_service][first]" value="all">
			<input type="hidden" name="cl_ongkir_service][ninja]" value="all">

			<table class="wp-list-table widefat fixed striped posts">
				<thead>
					<tr>
						<td width="200px"><b><?php esc_html_e( 'Tipe Tambahan Tarif', 'cl-ongkir' ); ?></b></td>
						<td>
							<select name="cl_ongkir_service][additional][type]">
								<option name="none">Tidak Aktif</option>
								<option name="fixed">Tambahan Tetap</option>
								<option name="percent">Tambahan Persentase</option>
							</select>
						</td>
					</tr>
					<tr>
						<td width="200px"><b><?php esc_html_e( 'Tambahan Tarif Tetap', 'cl-ongkir' ); ?></b></td>
						<td><input type="number" name="cl_ongkir_service][additional][fixed]"></td>
					</tr>
					<tr>
						<td width="200px"><b><?php esc_html_e( 'Tambahan Tarif Persentase', 'cl-ongkir' ); ?></b></td>
						<td><input type="number" name="cl_ongkir_service][additional][percent]"></td>
					</tr>
					<tr>
						<td width="200px"><b><?php esc_html_e( 'Nama Kurir', 'cl-ongkir' ); ?></b></td>
						<td><b><?php esc_html_e( 'Jenis Layanan', 'cl-ongkir' ); ?></b></td>
					</tr>
					<tr>
						<td width="200px"><b><?php esc_html_e( 'Nama Kurir', 'cl-ongkir' ); ?></b></td>
						<td><b><?php esc_html_e( 'Jenis Layanan', 'cl-ongkir' ); ?></b></td>
					</tr>
				</thead>
				<tbody>
					<tr class="cl-service-row jne">
						<td>JNE</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][jne][OKE]" id = "cl-ongkir-jne-oke" type="checkbox" <?php echo ( (isset($cl_services['jne']['OKE']) && $cl_services['jne']['OKE'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-oke">OKE</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][jne][REG]" id = "cl-ongkir-jne-reg" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['REG']) && $cl_services['jne']['REG'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-reg">Regular</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][jne][YES]" id = "cl-ongkir-jne-yes" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['YES']) && $cl_services['jne']['YES'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-yes">YES</label></div>
							<div class="courier-choice" style="display:none"><input name="cl_ongkir_service][jne][CTC]" id = "cl-ongkir-jne-ctc" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['CTC']) && $cl_services['jne']['CTC'] === "on") || (isset($cl_services['jne']['REG']) && $cl_services['jne']['REG'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-ctc">City To City</label></div>
							<div class="courier-choice" style="display:none"><input name="cl_ongkir_service][jne][CTCYES]" id = "cl-ongkir-jne-ctcyes" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['CTCYES']) && $cl_services['jne']['CTCYES'] === "on") || (isset($cl_services['jne']['YES']) && $cl_services['jne']['YES'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-ctcyes">City To City YES</label></div>
							<br />
							<p class="description"><?php esc_html_e( 'City To City dan City To City YES otomatis aktif jika REG atau YES di aktifkan.', 'cl-ongkir' ); ?></p>
						</td>
					</tr>

					<tr class="cl-service-row sicepat">
						<td>Si Cepat</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][sicepat][REG]" id="cl-ongkir-sicepat-reg" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['REG']) && $cl_services['sicepat']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-reg">Regular</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sicepat][BEST]" id="cl-ongkir-sicepat-best" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['BEST']) && $cl_services['sicepat']['BEST'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-best">Besok Sampai Tujuan</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sicepat][Priority]" id="cl-ongkir-sicepat-priority" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['Priority']) && $cl_services['sicepat']['Priority'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-priority">Priority</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sicepat][SIUNT]" id="cl-ongkir-sicepat-siunt" type="checkbox" <?php echo (isset($cl_services['sicepat']['SIUNT']) && $cl_services['sicepat']['SIUNT'] === "on") ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-siunt">Si Untung</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sicepat][GOKIL]" id="cl-ongkir-sicepat-cargo" type="checkbox" <?php echo (isset($cl_services['sicepat']['GOKIL']) && $cl_services['sicepat']['GOKIL'] === "on") ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-cargo">Cargo (Minimal 10kg)</label></div>
						</td>
					</tr>
					
					<tr class="cl-service-row anteraja">
						<td>AnterAja</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][anteraja][REG]" id="cl-ongkir-anteraja-reg" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['REG']) && $cl_services['anteraja']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-reg">Regular</label></div>
							
							<div class="courier-choice"><input name="cl_ongkir_service][anteraja][ND]" id="cl-ongkir-anteraja-nd" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['ND']) && $cl_services['anteraja']['ND'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-nd">Next Day</label></div>

							<div class="courier-choice"><input name="cl_ongkir_service][anteraja][SD]" id="cl-ongkir-anteraja-sd" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['SD']) && $cl_services['anteraja']['SD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-sd">Same Day</label></div>
						</td>
					</tr>

					<tr class="cl-service-row jnt">
						<td>J&T</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][J&T][EZ]" id="cl-ongkir-jnt-ez" type="checkbox" <?php echo ( (isset($cl_services['J&T']['EZ']) && $cl_services['J&T']['EZ'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jnt-ez">Regular Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row wahana">
						<td>Wahana</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][wahana][Normal]" id="cl-ongkir-wahana-reg" type="checkbox" <?php echo ( (isset($cl_services['wahana']['Normal']) && $cl_services['wahana']['Normal'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-wahana-reg">Normal</label></div>
						</td>
					</tr>

					<tr class="cl-service-row pos">
						<td>POS Indonesia</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Reguler]" id="cl-ongkir-pos-regular" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Reguler']) && $cl_services['pos']['Pos Reguler'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-regular">Pos Reguler</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Nextday]" id="cl-ongkir-pos-nextday" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Nextday']) && $cl_services['pos']['Pos Nextday'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-nextday">Pos Nextday</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Kargo]" id="cl-ongkir-pos-kargo" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Kargo']) && $cl_services['pos']['Pos Kargo'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-kargo">Pos Kargo</label></div>
						</td>
					</tr>

					<tr class="cl-service-row tiki">
						<td>TIKI</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][TRC]" id="cl-ongkir-tiki-trc" type="checkbox" <?php echo ( (isset($cl_services['tiki']['TRC']) && $cl_services['tiki']['TRC'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-trc">Trucking Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][REG]" id="cl-ongkir-tiki-reg" type="checkbox" <?php echo ( (isset($cl_services['tiki']['REG']) && $cl_services['tiki']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-reg">Regular</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][ECO]" id="cl-ongkir-tiki-eco" type="checkbox" <?php echo ( (isset($cl_services['tiki']['ECO']) && $cl_services['tiki']['ECO'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-eco">Economy</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][ONS]" id="cl-ongkir-tiki-ons" type="checkbox" <?php echo ( (isset($cl_services['tiki']['ONS']) && $cl_services['tiki']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-ons">Over Night Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][SDS]" id="cl-ongkir-tiki-sds" type="checkbox" <?php echo ( (isset($cl_services['tiki']['SDS']) && $cl_services['tiki']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-sds">Sameday Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][tiki][HDS]" id="cl-ongkir-tiki-hds" type="checkbox" <?php echo ( (isset($cl_services['tiki']['HDS']) && $cl_services['tiki']['HDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-hds">Holiday Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row lion">
						<td>Lion Parcel</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][lion][ONEPACK]" id="cl-ongkir-lion-ods" type="checkbox" <?php echo ( (isset($cl_services['lion']['ONEPACK']) && $cl_services['lion']['ONEPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-ods">One Day Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][lion][REGPACK]" id="cl-ongkir-lion-reg" type="checkbox" <?php echo ( (isset($cl_services['lion']['REGPACK']) && $cl_services['lion']['REGPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-reg">Regular Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][lion][LANDPACK]" id="cl-ongkir-lion-landpack" type="checkbox" <?php echo ( (isset($cl_services['lion']['LANDPACK']) && $cl_services['lion']['LANDPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-landpack">Logistic Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row rpx">
						<td>RPX</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][SDP]" id="cl-ongkir-rpx-sdp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['SDP']) && $cl_services['rpx']['SDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-sdp">SameDay Package</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][MDP]" id="cl-ongkir-rpx-mdp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['MDP']) && $cl_services['rpx']['MDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-mdp">MidDay Package</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][NDP]" id="cl-ongkir-rpx-ndp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['NDP']) && $cl_services['rpx']['NDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-ndp">NextDay Package</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][RGP]" id="cl-ongkir-rpx-rgp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['RGP']) && $cl_services['rpx']['RGP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-rgp">Regular Package</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][PSR]" id="cl-ongkir-rpx-psr" type="checkbox" <?php echo ( (isset($cl_services['rpx']['PSR']) && $cl_services['rpx']['PSR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-psr">PAS Reguler</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][rpx][PAS]" id="cl-ongkir-rpx-pas" type="checkbox" <?php echo ( (isset($cl_services['rpx']['PAS']) && $cl_services['rpx']['PAS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-pas">Paket Ambil Suka-Suka</label></div>
						</td>
					</tr>

					<tr class="cl-service-row pcp">
						<td>PCP</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][pcp][ONS]" id="cl-ongkir-pcp-ons" type="checkbox" <?php echo ( (isset($cl_services['pcp']['ONS']) && $cl_services['pcp']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-ons">Overnight Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pcp][NFS]" id="cl-ongkir-pcp-nfs" type="checkbox" <?php echo ( (isset($cl_services['pcp']['NFS']) && $cl_services['pcp']['NFS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-nfs">Next Flight Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pcp][REG]" id="cl-ongkir-pcp-reg" type="checkbox" <?php echo ( (isset($cl_services['pcp']['REG']) && $cl_services['pcp']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-reg">Regular Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row esl">
						<td>ESL</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][esl][RPX\/RDX]" id="cl-ongkir-esl-reg" type="checkbox" <?php echo ( (isset($cl_services['esl']['RPX\/RDX']) && $cl_services['esl']['RPX\/RDX'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-esl-reg">Paket Dokumen / Barang</label></div>
						</td>
					</tr>

					<tr class="cl-service-row pandu">
						<td>Pandu Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][pandu][REG]" id="cl-ongkir-pandu-reg" type="checkbox" <?php echo ( (isset($cl_services['pandu']['REG']) && $cl_services['pandu']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pandu-reg">Regular</label></div>
						</td>
					</tr>

					<tr class="cl-service-row pahala">
						<td>Pahala</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][pahala][REGULER]" id="cl-ongkir-pahala-reg" type="checkbox" <?php echo ( (isset($cl_services['pahala']['REGULER']) && $cl_services['pahala']['REGULER'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-reg">Regular</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pahala][PRIMA EXPRESS]" id="cl-ongkir-pahala-prima" type="checkbox" <?php echo ( (isset($cl_services['pahala']['PRIMA EXPRESS']) && $cl_services['pahala']['PRIMA EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-prima">Prima Express</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][pahala][SUPER EXPRESS]" id="cl-ongkir-pahala-super" type="checkbox" <?php echo ( (isset($cl_services['pahala']['SUPER EXPRESS']) && $cl_services['pahala']['SUPER EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-super">Super Express</label></div>
						</td>
					</tr>

					<tr class="cl-service-row cahaya">
						<td>Cahaya</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][cahaya][REG]" id="cl-ongkir-cahaya-reg" type="checkbox" <?php echo ( (isset($cl_services['cahaya']['REG']) && $cl_services['cahaya']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-cahaya-reg">Regular</label></div>
						</td>
					</tr>

					<tr class="cl-service-row sap">
						<td>SAP Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][sap][REG]" id="cl-ongkir-sap-reg" type="checkbox" <?php echo ( (isset($cl_services['sap']['REG']) && $cl_services['sap']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-reg">Regular</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sap][CARGO DARAT]" id="cl-ongkir-sap-cargo" type="checkbox" <?php echo ( (isset($cl_services['sap']['CARGO DARAT']) && $cl_services['sap']['CARGO DARAT'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-cargo">Cargo Darat (Minimal 5 kg)</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][sap][ODS]" id="cl-ongkir-sap-ods" type="checkbox" <?php echo ( (isset($cl_services['sap']['ODS']) && $cl_services['sap']['ODS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-ods">One Day Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row indah">
						<td>Indah Logistic</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][indah][DARAT]" id="cl-ongkir-indah-darat" type="checkbox" <?php echo ( (isset($cl_services['indah']['DARAT']) && $cl_services['indah']['DARAT'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-indah-darat">Darat</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][indah][UDARA]" id="cl-ongkir-indah-udara" type="checkbox" <?php echo ( (isset($cl_services['indah']['UDARA']) && $cl_services['indah']['UDARA'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-indah-udara">Udara</label></div>
						</td>
					</tr>

					<tr class="cl-service-row slis">
						<td>Solusi Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][slis][REGULAR]" id="cl-ongkir-slis-reg" type="checkbox" <?php echo ( (isset($cl_services['slis']['REGULAR']) && $cl_services['slis']['REGULAR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-slis-reg">Regular Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][slis][EXPRESS]" id="cl-ongkir-slis-exp" type="checkbox" <?php echo ( (isset($cl_services['slis']['EXPRESS']) && $cl_services['slis']['EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-slis-exp">Express Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row dse">
						<td>21 Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][dse][SDS]" id="cl-ongkir-dse-sds" type="checkbox" <?php echo ( (isset($cl_services['dse']['SDS']) && $cl_services['dse']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-sds">Same Day Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][dse][ONS]" id="cl-ongkir-dse-ons" type="checkbox" <?php echo ( (isset($cl_services['dse']['ONS']) && $cl_services['dse']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-ons">Over Night Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][dse][ECO]" id="cl-ongkir-dse-eco" type="checkbox" <?php echo ( (isset($cl_services['dse']['ECO']) && $cl_services['dse']['ECO'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-eco">Regular Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row first">
						<td>First Logistics</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][first][REG]" id="cl-ongkir-first-reg" type="checkbox" <?php echo ( (isset($cl_services['first']['REG']) && $cl_services['first']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-first-reg">Regular</label></div>
						</td>
					</tr>

					<tr class="cl-service-row ncs">
						<td>NCS</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][ncs][NRS]" id="cl-ongkir-ncs-nrs" type="checkbox" <?php echo ( (isset($cl_services['ncs']['NRS']) && $cl_services['ncs']['NRS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-nrs">Regular Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][ncs][ONS]" id="cl-ongkir-ncs-ons" type="checkbox" <?php echo ( (isset($cl_services['ncs']['ONS']) && $cl_services['ncs']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-ons">Overnight Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][ncs][SDS]" id="cl-ongkir-ncs-sds" type="checkbox" <?php echo ( (isset($cl_services['ncs']['SDS']) && $cl_services['ncs']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-sds">Same Day Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row star">
						<td>STAR Cargo</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][star][REGULER]" id="cl-ongkir-star-reg" type="checkbox" <?php echo ( (isset($cl_services['star']['REGULER']) && $cl_services['star']['REGULER'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-reg">REGULER DARAT</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][star][EXPRESS]" id="cl-ongkir-star-exp" type="checkbox" <?php echo ( (isset($cl_services['star']['EXPRESS']) && $cl_services['star']['EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-exp">Express</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][star][PARCEL]" id="cl-ongkir-star-parcel" type="checkbox" <?php echo ( (isset($cl_services['star']['PARCEL']) && $cl_services['star']['PARCEL'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-parcel">PARCEL DARAT</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][star][Dokumen]" id="cl-ongkir-star-doc" type="checkbox" <?php echo ( (isset($cl_services['star']['Dokumen']) && $cl_services['star']['Dokumen'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-doc">Dokumen Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][star][MOTOR]" id="cl-ongkir-star-mot" type="checkbox" <?php echo ( (isset($cl_services['star']['MOTOR']) && $cl_services['star']['MOTOR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-mot">Motor Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][star][MOTOR 150 - 250 CC]" id="cl-ongkir-star-mot2" type="checkbox" <?php echo ( (isset($cl_services['star']['MOTOR 150 - 250 CC']) && $cl_services['star']['MOTOR 150 - 250 CC'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-mot2">Motor 150 - 250 CC Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row ninja">
						<td>Ninja Xpress</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][ninja][STANDARD]" id="cl-ongkir-ninja-standard" type="checkbox" <?php echo ( (isset($cl_services['ninja']['STANDARD']) && $cl_services['ninja']['STANDARD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ninja-standard">Standard Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row idl">
						<td>IDL Cargo</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][idl][iCon]" id="cl-ongkir-idl-con" type="checkbox" <?php echo ( (isset($cl_services['idl']['iCon']) && $cl_services['idl']['iCon'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-con">Same Day Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][idl][iREG]" id="cl-ongkir-idl-reg" type="checkbox" <?php echo ( (isset($cl_services['idl']['iREG']) && $cl_services['idl']['iREG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-reg">Regular Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][idl][iSDS]" id="cl-ongkir-idl-sds" type="checkbox" <?php echo ( (isset($cl_services['idl']['iSDS']) && $cl_services['idl']['iSDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-sds">Same Day Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][idl][iONS]" id="cl-ongkir-idl-ons" type="checkbox" <?php echo ( (isset($cl_services['idl']['iONS']) && $cl_services['idl']['iONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-ons">Overnight Service</label></div>
							<div class="courier-choice"><input name="cl_ongkir_service][idl][iSCF]" id="cl-ongkir-idl-scf" type="checkbox" <?php echo ( (isset($cl_services['idl']['iSCF']) && $cl_services['idl']['iSCF'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-scf">Special Fleet</label></div>
						</td>
					</tr>

					<tr class="cl-service-row sentral">
						<td>Sentral Cargo</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][sentral][DARAT ELEKTRONIK]" id="cl-ongkir-sentral-darat-elektronik" type="checkbox" <?php echo ( (isset($cl_services['sentral']['DARAT ELEKTRONIK']) && $cl_services['sentral']['DARAT ELEKTRONIK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sentral-darat-elektronik">Darat Elektronik</label></div>
							
							<div class="courier-choice"><input name="cl_ongkir_service][sentral][DARAT NON ELEKTRONIK]" id="cl-ongkir-sentral-darat-non-elektronik" type="checkbox" <?php echo ( (isset($cl_services['sentral']['DARAT NON ELEKTRONIK']) && $cl_services['sentral']['DARAT NON ELEKTRONIK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sentral-darat-non-elektronik">Darat Non Elektronik</label></div>
						</td>
					</tr>

					<tr class="cl-service-row ide">
						<td>ID Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][ide][STD]" id="cl-ongkir-ide-std" type="checkbox" <?php echo ( (isset($cl_services['ide']['STD']) && $cl_services['ide']['STD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ide-std">Standard Service</label></div>
						</td>
					</tr>

					<tr class="cl-service-row rex">
						<td>REX</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][rex][REX-10]" id="cl-ongkir-rex-rex-10" type="checkbox" <?php echo ( (isset($cl_services['rex']['REX-10']) && $cl_services['rex']['REX-10'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-rex-10">REX-10</label></div>
							
							<div class="courier-choice"><input name="cl_ongkir_service][rex][REX-1]" id="cl-ongkir-rex-rex-1" type="checkbox" <?php echo ( (isset($cl_services['rex']['REX-1']) && $cl_services['rex']['REX-1'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-rex-1">REX-1</label></div>

							<div class="courier-choice"><input name="cl_ongkir_service][rex][EXP]" id="cl-ongkir-rex-exp" type="checkbox" <?php echo ( (isset($cl_services['rex']['EXP']) && $cl_services['rex']['EXP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-exp">Express</label></div>
						</td>
					</tr>

					<tr class="cl-service-row jtl">
						<td>JTL Express</td>
						<td>
							<div class="courier-choice"><input name="cl_ongkir_service][jtl][JTL EXTRA]" id="cl-ongkir-jtl-extra" type="checkbox" <?php echo ( (isset($cl_services['jtl']['JTL EXTRA']) && $cl_services['jtl']['JTL EXTRA'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-extra">JTL Extra</label></div>
							
							<div class="courier-choice"><input name="cl_ongkir_service][jtl][EXPRESS STANDART]" id="cl-ongkir-jtl-express-standart" type="checkbox" <?php echo ( (isset($cl_services['jtl']['EXPRESS STANDART']) && $cl_services['jtl']['EXPRESS STANDART'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-express-standart">Express Standart</label></div>
							
							<div class="courier-choice"><input name="cl_ongkir_service][jtl][EXPRESS ECONOMY]" id="cl-ongkir-jtl-express-ekonomy" type="checkbox" <?php echo ( (isset($cl_services['jtl']['EXPRESS ECONOMY']) && $cl_services['jtl']['EXPRESS ECONOMY'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-express-ekonomy">Express Economy</label></div>
						</td>
					</tr>
				</tbody>
			</table>
		</td>
		</tr>
		<style>
		.courier-choice {
			position: relative;
			float: left;
			padding: 5px;
		}
		.courier-label {
			min-width: 150px;
		}
		</style>
		 <?php
		return ob_get_clean();
	}

	/**
	 * Form for service ajax settings in admin
	 *
	 * @return void
	 */
	public function generate_cl_enable_service_ajax_html() {
		ob_start();
		$cl_services = get_option('cl_ongkir_services'.$this->instance_id);
		$cl_choose = get_option('cl_ongkir_choose_key');
		if( empty($cl_choose) || $cl_choose == 'custom' )
			$type = $this->settings['type_ongkir'];
		else
			$type = 'pro';
		?>
		<thead>
			<tr>
				<td colspan="2">
					<h3><?php esc_html_e('Gratis Ongkir', 'cl-ongkir'); ?></h3>
					<p><?php esc_html_e('Pengaturan fitur gratis ongkir dari plugin Cepatlakoo Ongkir.', 'cl-ongkir'); ?></p>
				</td>
			</tr>
			<tr>
				<td width="200px"><b><?php esc_html_e( 'Gratis Ongkir', 'cl-ongkir' ); ?></b></td>
				<td>
					<label for="cl-ongkir-free-status"><input type="checkbox" name="cl_ongkir_service][free][status]" id="cl-ongkir-free-status" value="1" <?php echo ( (isset($cl_services['free']['status']) && $cl_services['free']['status'] === "1") ) ? "checked" : ''; ?>> <?php esc_html_e( 'Aktifkan gratis ongkir', 'cl-ongkir' ); ?></label>
				</td>
			</tr>
			<tr class="cl-ongkir-fee-type">
				<td width="200px"><b><?php esc_html_e( 'Kebijakan Gratis Ongkir', 'cl-ongkir' ); ?></b></td>
				<td>
					<select name="cl_ongkir_service][free][type]" class="cl-ongkir-free-type">
						<option value="none" <?php echo ( (!isset($cl_services['free']['type']) || $cl_services['free']['type'] === "none") ) ? "selected" : ''; ?>><?php esc_html_e( 'Tidak ada, semua pesanan gratis ongkir', 'cl-ongkir' ); ?></option>
						<option value="coupon" <?php echo ( (isset($cl_services['free']['type']) && $cl_services['free']['type'] === "coupon") ) ? "selected" : ''; ?>><?php esc_html_e( 'Berdasarkan kode kupon yang valid', 'cl-ongkir' ); ?></option>
						<option value="min_amount" <?php echo ( (isset($cl_services['free']['type']) && $cl_services['free']['type'] === "min_amount") ) ? "selected" : ''; ?>><?php esc_html_e( 'Berdasarkan jumlah minimal nominal pesanan', 'cl-ongkir' ); ?></option>
						<option value="either" <?php echo ( (isset($cl_services['free']['type']) && $cl_services['free']['type'] === "either") ) ? "selected" : ''; ?>><?php esc_html_e( 'Berdasarkan jumlah minimal nominal pesanan ATAU kode kupon', 'cl-ongkir' ); ?></option>
						<option value="both" <?php echo ( (isset($cl_services['free']['type']) && $cl_services['free']['type'] === "both") ) ? "selected" : ''; ?>><?php esc_html_e( 'Berdasarkan jumlah minimal nominal pesanan DAN kode kupon', 'cl-ongkir' ); ?></option>
					</select>
				</td>
			</tr>
			<tr class="cl-ongkir-free-min-amount">
				<td>
					<label for="cl-ongkir-free-min-amount"><b><?php esc_html_e( 'Minimal nominal pesanan', 'cl-ongkir' ); ?></b></label>
				</td>
				<td>
					<?php echo get_woocommerce_currency_symbol(); ?> <input class="wc_input_price input-text regular-input small-text cl-number-only" type="number" name="cl_ongkir_service][free][min_amount]" id="cl-ongkir-free-min-amount" value="<?php echo (isset($cl_services['free']['min_amount']) && !empty($cl_services['free']['min_amount']) ) ? $cl_services['free']['min_amount'] : '0'; ?>" placeholder="0" style="width: 120px; min-width: 120px;">
				</td>
			</tr>
			<tr class="cl-ongkir-free-hide-reg">
				<td><b><?php esc_html_e( 'Sembunyikan ongkir berbayar', 'cl-ongkir' ); ?></b></td>
				<td>
					<label for="cl-ongkir-free-hide-reg"><input type="checkbox" name="cl_ongkir_service][free][hide_other]" id="cl-ongkir-free-hide-reg" value="1" <?php echo ( (isset($cl_services['free']['hide_other']) && $cl_services['free']['hide_other'] === "1") ) ? "checked" : ''; ?>> <?php esc_html_e( 'Sembunyikan ongkir berbayar di halaman checkout', 'cl-ongkir' ); ?></label>
				</td>
			</tr>
			<tr class="cl-ongkir-free-ignore">
				<td width="200px"><b><?php esc_html_e( 'Kupon Diskon', 'cl-ongkir' ); ?></b></td>
				<td>
					<label for="cl-ongkir-free-ignore"><input type="checkbox" name="cl_ongkir_service][free][ignore]" id="cl-ongkir-free-ignore" value="1" <?php echo ( (isset($cl_services['free']['ignore']) && $cl_services['free']['ignore'] === "1") ) ? "checked" : ''; ?>> <?php esc_html_e( 'Terapkan minimum pemesanan sebelum kupon diskon.', 'cl-ongkir' ); ?></label>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<h3><?php esc_html_e('Markup Biaya Ongkir', 'cl-ongkir'); ?></h3>
					<p><?php esc_html_e('Pengaturan fitur markup biaya ongkir dari plugin Cepatlakoo Ongkir.', 'cl-ongkir'); ?></p>
				</td>
			</tr>
			<tr>
				<td width="200px"><b><?php esc_html_e( 'Markup Biaya Ongkir', 'cl-ongkir' ); ?></b></td>
				<td>
					<select name="cl_ongkir_service][additional][type]" class="cl-ongkir-add-fee">
						<option value="none" <?php echo ( (!isset($cl_services['additional']['type']) || $cl_services['additional']['type'] === "none") ) ? "selected" : ''; ?>><?php esc_html_e( 'Nonaktifkan', 'cl-ongkir' ); ?></option>
						<option value="fixed" <?php echo ( (isset($cl_services['additional']['type']) && $cl_services['additional']['type'] === "fixed") ) ? "selected" : ''; ?>><?php esc_html_e( 'Menggunakan Biaya Tetap', 'cl-ongkir' ); ?></option>
						<option value="percent" <?php echo ( (isset($cl_services['additional']['type']) && $cl_services['additional']['type'] === "percent") ) ? "selected" : ''; ?>><?php esc_html_e( 'Menggunakan Persentase', 'cl-ongkir' ); ?></option>
					</select>
				</td>
			</tr>
			<tr class="cl-ongkir-add-fee-fixed">
				<td width="200px"><b><?php esc_html_e( 'Besaran Biaya Tetap', 'cl-ongkir' ); ?></b></td>
				<td><?php echo get_woocommerce_currency_symbol(); ?> <input type="number" class=" cl-number-only" name="cl_ongkir_service][additional][fixed]" value="<?php echo (isset($cl_services['additional']['fixed']) && !empty($cl_services['additional']['fixed']) ) ? $cl_services['additional']['fixed'] : ''; ?>"  style="width: 120px; min-width: 120px;"></td>
			</tr>
			<tr class="cl-ongkir-add-fee-percent">
				<td width="200px"><b><?php esc_html_e( 'Besaran Persentase', 'cl-ongkir' ); ?></b></td>
				<td><input type="number" name="cl_ongkir_service][additional][percent]" class=" cl-number-only" min=1 max=1000 value="<?php echo (isset($cl_services['additional']['percent']) && !empty($cl_services['additional']['percent']) ) ? $cl_services['additional']['percent'] : ''; ?>" style="width: 75px; min-width: 75px;"> %</td>
			</tr>
			<tr><td colspan="2"><h3><?php esc_html_e( 'Daftar Layanan Kurir', 'cl-ongkir' ); ?></h3></td></tr>
			<tr>
				<td width="200px"><b><?php esc_html_e( 'Nama Kurir', 'cl-ongkir' ); ?></b></td>
				<td><b><?php esc_html_e( 'Jenis Layanan', 'cl-ongkir' ); ?></b>
				<span style="float: right;"><a href="#" class="cl-ongkir-select-all"><?php esc_html_e( 'Select All', 'cl-ongkir' ); ?></a> | <a href="#" class="cl-ongkir-deselect-all"><?php esc_html_e( 'Deselect All', 'cl-ongkir' ); ?></a></span>
				</td>
				<input type="hidden" class="cl_ongkir_shipping_type_ongkir" value="<?php echo $type; ?>">
			</tr>
		</thead>
		<tbody class="cl-ongkir-zones-services">
			<tr class="cl-service-row jne">
				<td>JNE</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][jne][OKE]" id = "cl-ongkir-jne-oke" type="checkbox" <?php echo ( (isset($cl_services['jne']['OKE']) && $cl_services['jne']['OKE'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-oke">OKE</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][jne][REG]" id = "cl-ongkir-jne-reg" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['REG']) && $cl_services['jne']['REG'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-reg">Regular</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][jne][YES]" id = "cl-ongkir-jne-yes" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['YES']) && $cl_services['jne']['YES'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-yes">YES</label></div>
					<div class="courier-choice" style="display:none"><input name="cl_ongkir_service][jne][CTC]" id = "cl-ongkir-jne-ctc" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['CTC']) && $cl_services['jne']['CTC'] === "on") || (isset($cl_services['jne']['REG']) && $cl_services['jne']['REG'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-ctc">City To City</label></div>
					<div class="courier-choice" style="display:none"><input name="cl_ongkir_service][jne][CTCYES]" id = "cl-ongkir-jne-ctcyes" type="checkbox" <?php echo ( $cl_services == false || (isset($cl_services['jne']['CTCYES']) && $cl_services['jne']['CTCYES'] === "on") || (isset($cl_services['jne']['YES']) && $cl_services['jne']['YES'] === "on") ) ? "checked" : ''; ?>> <label for="cl-ongkir-jne-ctcyes">City To City YES</label></div>
					<br />
					<p class="description"><?php esc_html_e( 'City To City dan City To City YES otomatis aktif jika REG atau YES di aktifkan.', 'cl-ongkir' ); ?></p>
				</td>
			</tr>

			<tr class="cl-service-row sicepat">
				<td>Si Cepat</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][sicepat][REG]" id="cl-ongkir-sicepat-reg" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['REG']) && $cl_services['sicepat']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-reg">Regular</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sicepat][BEST]" id="cl-ongkir-sicepat-best" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['BEST']) && $cl_services['sicepat']['BEST'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-best">Besok Sampai Tujuan</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sicepat][Priority]" id="cl-ongkir-sicepat-priority" type="checkbox" <?php echo ( (isset($cl_services['sicepat']['Priority']) && $cl_services['sicepat']['Priority'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-priority">Priority</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sicepat][SIUNT]" id="cl-ongkir-sicepat-siunt" type="checkbox" <?php echo (isset($cl_services['sicepat']['SIUNT']) && $cl_services['sicepat']['SIUNT'] === "on") ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-siunt">Si Untung</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sicepat][GOKIL]" id="cl-ongkir-sicepat-cargo" type="checkbox" <?php echo (isset($cl_services['sicepat']['GOKIL']) && $cl_services['sicepat']['GOKIL'] === "on") ? "checked" : ''; ?> ><label for="cl-ongkir-sicepat-cargo">Cargo (Minimal 10kg)</label></div>
				</td>
			</tr>
			
			<tr class="cl-service-row anteraja">
				<td>AnterAja</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][anteraja][REG]" id="cl-ongkir-anteraja-reg" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['REG']) && $cl_services['anteraja']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-reg">Regular</label></div>
					
					<div class="courier-choice"><input name="cl_ongkir_service][anteraja][ND]" id="cl-ongkir-anteraja-nd" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['ND']) && $cl_services['anteraja']['ND'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-nd">Next Day</label></div>

					<div class="courier-choice"><input name="cl_ongkir_service][anteraja][SD]" id="cl-ongkir-anteraja-sd" type="checkbox" <?php echo ( (isset($cl_services['anteraja']['SD']) && $cl_services['anteraja']['SD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-anteraja-sd">Same Day</label></div>
				</td>
			</tr>

			<tr class="cl-service-row jnt">
				<td>J&T</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][J&T][EZ]" id="cl-ongkir-jnt-ez" type="checkbox" <?php echo ( (isset($cl_services['J&T']['EZ']) && $cl_services['J&T']['EZ'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jnt-ez">Regular Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row wahana">
				<td>Wahana</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][wahana][Normal]" id="cl-ongkir-wahana-reg" type="checkbox" <?php echo ( (isset($cl_services['wahana']['Normal']) && $cl_services['wahana']['Normal'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-wahana-reg">Normal</label></div>
				</td>
			</tr>

			<tr class="cl-service-row pos">
				<td>POS Indonesia</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Reguler]" id="cl-ongkir-pos-regular" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Reguler']) && $cl_services['pos']['Pos Reguler'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-regular">Pos Reguler</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Nextday]" id="cl-ongkir-pos-nextday" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Nextday']) && $cl_services['pos']['Pos Nextday'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-nextday">Pos Nextday</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pos][Pos Kargo]" id="cl-ongkir-pos-kargo" type="checkbox" <?php echo ( (isset($cl_services['pos']['Pos Kargo']) && $cl_services['pos']['Pos Kargo'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pos-kargo">Pos Kargo</label></div>
				</td>
			</tr>

			<tr class="cl-service-row tiki">
				<td>TIKI</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][TRC]" id="cl-ongkir-tiki-trc" type="checkbox" <?php echo ( (isset($cl_services['tiki']['TRC']) && $cl_services['tiki']['TRC'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-trc">Trucking Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][REG]" id="cl-ongkir-tiki-reg" type="checkbox" <?php echo ( (isset($cl_services['tiki']['REG']) && $cl_services['tiki']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-reg">Regular</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][ECO]" id="cl-ongkir-tiki-eco" type="checkbox" <?php echo ( (isset($cl_services['tiki']['ECO']) && $cl_services['tiki']['ECO'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-eco">Economy</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][ONS]" id="cl-ongkir-tiki-ons" type="checkbox" <?php echo ( (isset($cl_services['tiki']['ONS']) && $cl_services['tiki']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-ons">Over Night Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][SDS]" id="cl-ongkir-tiki-sds" type="checkbox" <?php echo ( (isset($cl_services['tiki']['SDS']) && $cl_services['tiki']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-sds">Sameday Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][tiki][HDS]" id="cl-ongkir-tiki-hds" type="checkbox" <?php echo ( (isset($cl_services['tiki']['HDS']) && $cl_services['tiki']['HDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-tiki-hds">Holiday Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row lion">
				<td>Lion Parcel</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][lion][ONEPACK]" id="cl-ongkir-lion-ods" type="checkbox" <?php echo ( (isset($cl_services['lion']['ONEPACK']) && $cl_services['lion']['ONEPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-ods">One Day Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][lion][REGPACK]" id="cl-ongkir-lion-reg" type="checkbox" <?php echo ( (isset($cl_services['lion']['REGPACK']) && $cl_services['lion']['REGPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-reg">Regular Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][lion][LANDPACK]" id="cl-ongkir-lion-landpack" type="checkbox" <?php echo ( (isset($cl_services['lion']['LANDPACK']) && $cl_services['lion']['LANDPACK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-lion-landpack">Logistic Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row rpx">
				<td>RPX</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][SDP]" id="cl-ongkir-rpx-sdp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['SDP']) && $cl_services['rpx']['SDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-sdp">SameDay Package</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][MDP]" id="cl-ongkir-rpx-mdp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['MDP']) && $cl_services['rpx']['MDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-mdp">MidDay Package</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][NDP]" id="cl-ongkir-rpx-ndp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['NDP']) && $cl_services['rpx']['NDP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-ndp">NextDay Package</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][RGP]" id="cl-ongkir-rpx-rgp" type="checkbox" <?php echo ( (isset($cl_services['rpx']['RGP']) && $cl_services['rpx']['RGP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-rgp">Regular Package</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][PSR]" id="cl-ongkir-rpx-psr" type="checkbox" <?php echo ( (isset($cl_services['rpx']['PSR']) && $cl_services['rpx']['PSR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-psr">PAS Reguler</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][rpx][PAS]" id="cl-ongkir-rpx-pas" type="checkbox" <?php echo ( (isset($cl_services['rpx']['PAS']) && $cl_services['rpx']['PAS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rpx-pas">Paket Ambil Suka-Suka</label></div>
				</td>
			</tr>

			<tr class="cl-service-row pcp">
				<td>PCP</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][pcp][ONS]" id="cl-ongkir-pcp-ons" type="checkbox" <?php echo ( (isset($cl_services['pcp']['ONS']) && $cl_services['pcp']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-ons">Overnight Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pcp][NFS]" id="cl-ongkir-pcp-nfs" type="checkbox" <?php echo ( (isset($cl_services['pcp']['NFS']) && $cl_services['pcp']['NFS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-nfs">Next Flight Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pcp][REG]" id="cl-ongkir-pcp-reg" type="checkbox" <?php echo ( (isset($cl_services['pcp']['REG']) && $cl_services['pcp']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pcp-reg">Regular Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row esl">
				<td>ESL</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][esl][RPX\/RDX]" id="cl-ongkir-esl-reg" type="checkbox" <?php echo ( (isset($cl_services['esl']['RPX\/RDX']) && $cl_services['esl']['RPX\/RDX'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-esl-reg">Paket Dokumen / Barang</label></div>
				</td>
			</tr>

			<tr class="cl-service-row pandu">
				<td>Pandu Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][pandu][REG]" id="cl-ongkir-pandu-reg" type="checkbox" <?php echo ( (isset($cl_services['pandu']['REG']) && $cl_services['pandu']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pandu-reg">Regular</label></div>
				</td>
			</tr>

			<tr class="cl-service-row pahala">
				<td>Pahala</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][pahala][REGULER]" id="cl-ongkir-pahala-reg" type="checkbox" <?php echo ( (isset($cl_services['pahala']['REGULER']) && $cl_services['pahala']['REGULER'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-reg">Regular</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pahala][PRIMA EXPRESS]" id="cl-ongkir-pahala-prima" type="checkbox" <?php echo ( (isset($cl_services['pahala']['PRIMA EXPRESS']) && $cl_services['pahala']['PRIMA EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-prima">Prima Express</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][pahala][SUPER EXPRESS]" id="cl-ongkir-pahala-super" type="checkbox" <?php echo ( (isset($cl_services['pahala']['SUPER EXPRESS']) && $cl_services['pahala']['SUPER EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-pahala-super">Super Express</label></div>
				</td>
			</tr>

			<tr class="cl-service-row cahaya">
				<td>Cahaya</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][cahaya][REG]" id="cl-ongkir-cahaya-reg" type="checkbox" <?php echo ( (isset($cl_services['cahaya']['REG']) && $cl_services['cahaya']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-cahaya-reg">Regular</label></div>
				</td>
			</tr>

			<tr class="cl-service-row sap">
				<td>SAP Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][sap][REG]" id="cl-ongkir-sap-reg" type="checkbox" <?php echo ( (isset($cl_services['sap']['REG']) && $cl_services['sap']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-reg">Regular</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sap][CARGO DARAT]" id="cl-ongkir-sap-cargo" type="checkbox" <?php echo ( (isset($cl_services['sap']['CARGO DARAT']) && $cl_services['sap']['CARGO DARAT'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-cargo">Cargo Darat (Minimal 5 kg)</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][sap][ODS]" id="cl-ongkir-sap-ods" type="checkbox" <?php echo ( (isset($cl_services['sap']['ODS']) && $cl_services['sap']['ODS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sap-ods">One Day Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row indah">
				<td>Indah Logistic</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][indah][DARAT]" id="cl-ongkir-indah-darat" type="checkbox" <?php echo ( (isset($cl_services['indah']['DARAT']) && $cl_services['indah']['DARAT'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-indah-darat">Darat</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][indah][UDARA]" id="cl-ongkir-indah-udara" type="checkbox" <?php echo ( (isset($cl_services['indah']['UDARA']) && $cl_services['indah']['UDARA'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-indah-udara">Udara</label></div>
				</td>
			</tr>

			<tr class="cl-service-row slis">
				<td>Solusi Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][slis][REGULAR]" id="cl-ongkir-slis-reg" type="checkbox" <?php echo ( (isset($cl_services['slis']['REGULAR']) && $cl_services['slis']['REGULAR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-slis-reg">Regular Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][slis][EXPRESS]" id="cl-ongkir-slis-exp" type="checkbox" <?php echo ( (isset($cl_services['slis']['EXPRESS']) && $cl_services['slis']['EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-slis-exp">Express Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row dse">
				<td>21 Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][dse][SDS]" id="cl-ongkir-dse-sds" type="checkbox" <?php echo ( (isset($cl_services['dse']['SDS']) && $cl_services['dse']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-sds">Same Day Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][dse][ONS]" id="cl-ongkir-dse-ons" type="checkbox" <?php echo ( (isset($cl_services['dse']['ONS']) && $cl_services['dse']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-ons">Over Night Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][dse][ECO]" id="cl-ongkir-dse-eco" type="checkbox" <?php echo ( (isset($cl_services['dse']['ECO']) && $cl_services['dse']['ECO'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-dse-eco">Regular Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row first">
				<td>First Logistics</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][first][REG]" id="cl-ongkir-first-reg" type="checkbox" <?php echo ( (isset($cl_services['first']['REG']) && $cl_services['first']['REG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-first-reg">Regular</label></div>
				</td>
			</tr>

			<tr class="cl-service-row ncs">
				<td>NCS</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][ncs][NRS]" id="cl-ongkir-ncs-nrs" type="checkbox" <?php echo ( (isset($cl_services['ncs']['NRS']) && $cl_services['ncs']['NRS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-nrs">Regular Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][ncs][ONS]" id="cl-ongkir-ncs-ons" type="checkbox" <?php echo ( (isset($cl_services['ncs']['ONS']) && $cl_services['ncs']['ONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-ons">Overnight Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][ncs][SDS]" id="cl-ongkir-ncs-sds" type="checkbox" <?php echo ( (isset($cl_services['ncs']['SDS']) && $cl_services['ncs']['SDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ncs-sds">Same Day Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row star">
				<td>STAR Cargo</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][star][REGULER]" id="cl-ongkir-star-reg" type="checkbox" <?php echo ( (isset($cl_services['star']['REGULER']) && $cl_services['star']['REGULER'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-reg">REGULER DARAT</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][star][EXPRESS]" id="cl-ongkir-star-exp" type="checkbox" <?php echo ( (isset($cl_services['star']['EXPRESS']) && $cl_services['star']['EXPRESS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-exp">Express</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][star][PARCEL]" id="cl-ongkir-star-parcel" type="checkbox" <?php echo ( (isset($cl_services['star']['PARCEL']) && $cl_services['star']['PARCEL'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-parcel">PARCEL DARAT</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][star][Dokumen]" id="cl-ongkir-star-doc" type="checkbox" <?php echo ( (isset($cl_services['star']['Dokumen']) && $cl_services['star']['Dokumen'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-doc">Dokumen Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][star][MOTOR]" id="cl-ongkir-star-mot" type="checkbox" <?php echo ( (isset($cl_services['star']['MOTOR']) && $cl_services['star']['MOTOR'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-mot">Motor Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][star][MOTOR 150 - 250 CC]" id="cl-ongkir-star-mot2" type="checkbox" <?php echo ( (isset($cl_services['star']['MOTOR 150 - 250 CC']) && $cl_services['star']['MOTOR 150 - 250 CC'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-star-mot2">Motor 150 - 250 CC Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row ninja">
				<td>Ninja Xpress</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][ninja][STANDARD]" id="cl-ongkir-ninja-standard" type="checkbox" <?php echo ( (isset($cl_services['ninja']['STANDARD']) && $cl_services['ninja']['STANDARD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ninja-standard">Standard Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row idl">
				<td>IDL Cargo</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][idl][iCon]" id="cl-ongkir-idl-con" type="checkbox" <?php echo ( (isset($cl_services['idl']['iCon']) && $cl_services['idl']['iCon'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-con">Same Day Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][idl][iREG]" id="cl-ongkir-idl-reg" type="checkbox" <?php echo ( (isset($cl_services['idl']['iREG']) && $cl_services['idl']['iREG'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-reg">Regular Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][idl][iSDS]" id="cl-ongkir-idl-sds" type="checkbox" <?php echo ( (isset($cl_services['idl']['iSDS']) && $cl_services['idl']['iSDS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-sds">Same Day Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][idl][iONS]" id="cl-ongkir-idl-ons" type="checkbox" <?php echo ( (isset($cl_services['idl']['iONS']) && $cl_services['idl']['iONS'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-ons">Overnight Service</label></div>
					<div class="courier-choice"><input name="cl_ongkir_service][idl][iSCF]" id="cl-ongkir-idl-scf" type="checkbox" <?php echo ( (isset($cl_services['idl']['iSCF']) && $cl_services['idl']['iSCF'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-idl-scf">Special Fleet</label></div>
				</td>
			</tr>

			<tr class="cl-service-row sentral">
				<td>Sentral Cargo</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][sentral][DARAT ELEKTRONIK]" id="cl-ongkir-sentral-darat-elektronik" type="checkbox" <?php echo ( (isset($cl_services['sentral']['DARAT ELEKTRONIK']) && $cl_services['sentral']['DARAT ELEKTRONIK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sentral-darat-elektronik">Darat Elektronik</label></div>
					
					<div class="courier-choice"><input name="cl_ongkir_service][sentral][DARAT NON ELEKTRONIK]" id="cl-ongkir-sentral-darat-non-elektronik" type="checkbox" <?php echo ( (isset($cl_services['sentral']['DARAT NON ELEKTRONIK']) && $cl_services['sentral']['DARAT NON ELEKTRONIK'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-sentral-darat-non-elektronik">Darat Non Elektronik</label></div>
				</td>
			</tr>

			<tr class="cl-service-row ide">
				<td>ID Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][ide][STD]" id="cl-ongkir-ide-std" type="checkbox" <?php echo ( (isset($cl_services['ide']['STD']) && $cl_services['ide']['STD'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-ide-std">Standard Service</label></div>
				</td>
			</tr>

			<tr class="cl-service-row rex">
				<td>REX</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][rex][REX-10]" id="cl-ongkir-rex-rex-10" type="checkbox" <?php echo ( (isset($cl_services['rex']['REX-10']) && $cl_services['rex']['REX-10'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-rex-10">REX-10</label></div>
					
					<div class="courier-choice"><input name="cl_ongkir_service][rex][REX-1]" id="cl-ongkir-rex-rex-1" type="checkbox" <?php echo ( (isset($cl_services['rex']['REX-1']) && $cl_services['rex']['REX-1'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-rex-1">REX-1</label></div>

					<div class="courier-choice"><input name="cl_ongkir_service][rex][EXP]" id="cl-ongkir-rex-exp" type="checkbox" <?php echo ( (isset($cl_services['rex']['EXP']) && $cl_services['rex']['EXP'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-rex-exp">Express</label></div>
				</td>
			</tr>

			<tr class="cl-service-row jtl">
				<td>JTL Express</td>
				<td>
					<div class="courier-choice"><input name="cl_ongkir_service][jtl][JTL EXTRA]" id="cl-ongkir-jtl-extra" type="checkbox" <?php echo ( (isset($cl_services['jtl']['JTL EXTRA']) && $cl_services['jtl']['JTL EXTRA'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-extra">JTL Extra</label></div>
					
					<div class="courier-choice"><input name="cl_ongkir_service][jtl][EXPRESS STANDART]" id="cl-ongkir-jtl-express-standart" type="checkbox" <?php echo ( (isset($cl_services['jtl']['EXPRESS STANDART']) && $cl_services['jtl']['EXPRESS STANDART'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-express-standart">Express Standart</label></div>
					
					<div class="courier-choice"><input name="cl_ongkir_service][jtl][EXPRESS ECONOMY]" id="cl-ongkir-jtl-express-ekonomy" type="checkbox" <?php echo ( (isset($cl_services['jtl']['EXPRESS ECONOMY']) && $cl_services['jtl']['EXPRESS ECONOMY'] === "on") ) ? "checked" : ''; ?> ><label for="cl-ongkir-jtl-express-ekonomy">Express Economy</label></div>
				</td>
			</tr>
		</tbody>
		<style>
		.courier-choice {
			position: relative;
			float: left;
			padding: 5px;
		}
		.courier-label {
			min-width: 150px;
		}
		</style>
		 <?php
		return ob_get_clean();
	}

	/**
	 * Form for choose api key settings in admin
	 *
	 * @return void
	 */
	public function generate_cl_choose_key_html() {
		global $cl_ongkir;
		ob_start();
		$cl_choose = get_option('cl_ongkir_choose_key');
		$check = $cl_ongkir->cl_ongkir_check_license();
		$lic_valid = $check['cl'];
		$cl_valid = (isset($check['result']) ) ? $check['result'] : false;
		$cl_choose = (isset($cl_valid->status) && $cl_valid->status) ? $cl_choose : 'custom';
		$doms = (isset($cl_valid->domain)) ? explode(', ', $cl_valid->domain) : array();
		$max_domain = (isset( $check['raw']->price_id ) && $check['raw']->price_id == '1' ) ? 5 : (isset( $check['raw']->license_limit ) ? $check['raw']->license_limit : 0);
		?>
		<tr>
			<th scope="row" class="titledesc"><?php esc_html_e( 'Pilih API RajaOngkir', 'cl-ongkir' ); ?></th>
			<td style="height: 100px;">
				<table class="wp-list-table widefat fixed striped posts">
					<thead>
						<tr>
							<td><b><?php esc_html_e( 'Pilih API key RajaOngkir.com yang ingin Anda gunakan', 'cl-ongkir' ); ?></b></td>
						</tr>
					</thead>
					<tbody>
					<?php if( $lic_valid && isset($cl_valid->status) && $cl_valid->status ) : ?>
						<tr class="choose-api">
							<td>
								<input id="cl-choose-key-random" class="cl-choose-key" type="radio" name="cl-choose-key" value="random" <?php echo ($cl_choose == 'random') ? 'checked' : ''; ?>><label for="cl-choose-key-random"><?php echo sprintf( esc_html__( 'API Key Acak (Maks. %s Website)', 'cl-ongkir' ), $max_domain); ?></label>
								<div class="api-desc">
									<p><span class="description"><?php esc_html_e('Opsi ini menggunakan beberapa API Key RajaOngkir PRO milik Cepatlakoo secara acak. Layanan ini merupakan bonus layanan dari kami untuk Anda.', 'cl-ongkir'); ?> <?php esc_html_e('Dikarenakan digunakan bersama-sama pengguna Cepatlakoo lainnya serta ada limit untuk masing-masing API Key PRO maka ketersediaan layanan ini tidak sebaik menggunakan API Key RajaOngkir PRO milik Anda sendiri.', 'cl-ongkir'); ?></span></p>

									<p><?php echo sprintf( __('Maksimal hanya %s website yang bisa terkoneksi ke Cepatlakoo Ongkir per 1 kode lisensi Cepatlakoo. Domain yang telah terdaftar menggunakan API Acak Cepatlakoo Ongkir: ', 'cl-ongkir'), $max_domain); ?></p>

									<?php if ( is_array($doms) && count($doms) > 0 ) : ?>
										<ol class="domain-list">
											<?php foreach( $doms as $domain ): ?>
												<?php if( !empty($domain) ) : ?>
												<li><code><?php echo $domain; ?></code> - <a href="" data-domain="<?php echo $domain; ?>" class="cl-ongkir-remove-domain"><?php esc_html_e('Hapus', 'cl-ongkir'); ?></a></li>
												<?php endif; ?>
											<?php endforeach; ?>
										</ol>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php else : ?>
						<tr class="choose-api">
							<td>
								<input id="cl-choose-key-random" class="cl-choose-key" type="radio" name="cl-choose-key" value="random" <?php echo ($cl_choose == 'random') ? 'checked' : ''; ?> disabled><label for="cl-choose-key-random" class="disabled"><?php esc_html_e( 'API Key Acak', 'cl-ongkir' ); ?></label>
								<div class="api-desc">
									<p><?php echo sprintf(esc_html__('Jika ingin menggunakan API acak RajaOngkir milik Cepatlakoo, pastikan lisensi Cepatlakoo sudah diaktifkan, status kode lisensi milik Anda belum kadaluarsa dan 1 lisensi maksimal dapat di gunakan untuk %s website.', 'cl-ongkir'), $max_domain); ?>

									<?php if ( $lic_valid ) : ?>
										<a href="#" class="button button-primary cl-ongkir-register-domain"><?php esc_html_e('Daftarkan Domain', 'cl-ongkir'); ?></a>

										<p><small><?php esc_html_e('Jika tombol di atas tidak dapat diklik. Lakukan hard refresh pada browser dengan menekan tombol Shift+Ctrl+R (Windows) atau Shift+Cmd+R (Mac OS).', 'cl-ongkir'); ?></small></p>

									<?php else : ?>	
										<a href="<?php echo admin_url( '/themes.php?page=cepatlakoo-license'); ?>" class="button button-primary" target="_blank"><?php esc_html_e('Aktifkan Lisensi', 'cl-ongkir'); ?></a>
									<?php endif; ?>
									</p>

									<p><?php echo sprintf(esc_html__('Maksimal hanya %s website yang bisa terkoneksi ke API Acak Cepatlakoo Ongkir per 1 kode lisensi Cepatlakoo. Domain yang telah terdaftar menggunakan API Acak Cepatlakoo Ongkir: ', 'cl-ongkir'), $max_domain); ?></p>

									<?php if ( is_array($doms) && count($doms) > 0 ) : ?>
										<ol class="domain-list">
											<?php foreach( $doms as $domain ): ?>
												<?php if( !empty($domain) ) : ?>
												<li><code><?php echo $domain; ?></code> - <a href="" data-domain="<?php echo $domain; ?>" class="cl-ongkir-remove-domain"><?php esc_html_e('Hapus', 'cl-ongkir'); ?></a></li>
												<?php endif; ?>
											<?php endforeach; ?>
										</ol>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endif; ?>
						<tr class="choose-api">
							<td>
								<input id="cl-choose-key-custom" class="cl-choose-key" type="radio" name="cl-choose-key" value="custom" <?php echo ($cl_choose == 'custom') ? 'checked' : ''; ?>><label for="cl-choose-key-custom"><?php esc_html_e( 'API Key RajaOngkir Milik Anda', 'cl-ongkir' ); ?></label>
								<div class="api-desc">
									<p><?php esc_html_e('Gunakan API key RajaOngkir milik Anda sendiri. Silahkan input data API Key serta tipe Akun RajaOngkir Anda di bawah.', 'cl-ongkir'); ?></p>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</td>
		</tr>
		 <?php
		return ob_get_clean();
	}

	public static function round( $val, int $precision = 0, int $mode = PHP_ROUND_HALF_UP ) : float {
		if ( ! is_numeric( $val ) ) {
			$val = floatval( $val );
		}
		return round( $val, $precision, $mode );
	}
}
?>
