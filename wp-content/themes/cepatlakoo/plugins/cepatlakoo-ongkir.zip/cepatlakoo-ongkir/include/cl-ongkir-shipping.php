<?php
/**
 *
 * @author eezhal
 * @package myongkir/class
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( !class_exists('Request') ) {	
	require_once 'request.php';
}

require_once 'helper-functions.php';

class Cl_Ongkir_Shipping {

	private $api_key = '';

	private $choose = '';

	private static $request = null;

	protected static $instance;

	public function __construct() {

		$this->choose = get_option('cl_ongkir_choose_key');
		if( $this->choose != 'custom' ){
			$this->set_api_key();
		} 

		// if( strpos($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']  , 'section=cl_ongkir_shipping') ){
			if( false !== get_transient('cl-server-status-starter') && false !== get_transient('cl-server-status-pro') ){
				$this->pro_status = get_transient('cl-server-status-pro');
				$this->sta_status = get_transient('cl-server-status-starter');
			}
			else{
				$this->pro_status = $this->cl_check_connection('https://pro.rajaongkir.com/api');
				$this->sta_status = $this->cl_check_connection('https://api.rajaongkir.com/');
				
				set_transient('cl-server-status-pro', $this->pro_status, 30 * MINUTE_IN_SECONDS);
				set_transient('cl-server-status-starter', $this->sta_status, 30 * MINUTE_IN_SECONDS);
			}
		// }
		
		$type = get_option('woocommerce_type_account');
		$this->set_server($type);

		return self::$request;
	}

	/**
	 * Get instance of this class.
	 *
	 * @return MyOngkir_Shipping
	 */
	public static function get_instance() {
		if(!static::$instance) {
			static ::$instance = new self;
		}

		return static::$instance;
	}

	/**
	 * Set rajaongkir api key for request.
	 *
	 * @param string $api_key
	 * @return void
	 */
	public function set_api_key($api_key='') {
		$cl_choose = get_option('cl_ongkir_choose_key');
		
		if( $cl_choose == 'custom' ){
			$this->api_key = $api_key;
		}
		else{
			$this->api_key = '';
		}
	}

	/**
	 * Set method request for rajaongkir api.
	 *
	 * @param string $method
	 * @return void
	 */
	public function set_method($method) {
		$this->method = $method;
	}

	/**
	 * Set Choose for rajaongkir api.
	 *
	 * @param string $method
	 * @return void
	 */
	public function set_choose($choose) {
		$this->choose = $choose;
	}

	public function set_server($type){
		if( $this->choose != 'custom' ){
			$this->server = 'https://ongkir.cepatlakoo.com/api/v1';
		}
		else{
			if( $type == 'starter' ){
				$SERVER = 'https://api.rajaongkir.com/starter';
			}elseif( $type == 'basic' ){
				$SERVER = 'https://api.rajaongkir.com/basic';
			}elseif( $type == 'pro' ){
				$SERVER = 'https://pro.rajaongkir.com/api';
			}else{
				if ( isset($this->sta_status) && $this->sta_status == 0 ){
					$SERVER = 'https://api.rajaongkir.com/starter';
				}
				else {
					$SERVER = 'https://pro.rajaongkir.com/api';
				}
			}
			
			self::$request = new Request(array(
				'server' => $SERVER
			));
			$this->server = $SERVER;
			// set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
		}
	}

	/**
	 * Get shipping costs.
	 *
	 * @access public
	 * @param integer $from
	 * @param integer $to
	 * @param float $weight
	 * @return array
	 */
	public function get_costs( $from, $to, $weight, $courier = 'jne') {
		if(empty($to))
				return;

		if( false !== get_transient('cl-ongkir-get_costs'.$from.'-'.$to.'-'.$weight.'-'.$courier) && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') &&
		get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
			return get_transient('cl-ongkir-get_costs'.$from.'-'.$to.'-'.$weight.'-'.$courier);
		} else {
			$result = self::$request->post('/cost', array(
				'key'         		=> $this->api_key,
				'origin'      		=> $from,
				'destination' 		=> $to,
				'weight'      		=> $weight,
				'courier'     		=> $courier
			));

			try {
				if( $result) {
					if($result->rajaongkir->status->code != 400){
						$costs = object_to_array( $result->rajaongkir->results );
						$new_costs = object_to_array( $costs );
						set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
						set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
						set_transient('cl-ongkir-get_costs'.$from.'-'.$to.'-'.$weight.'-'.$courier, $new_costs, 12 * HOUR_IN_SECONDS);
					}else{
						$new_costs = '-';
					}
					return $new_costs;
				}else{
					return '-';
				}
			} catch ( Exception $e ) {
				var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
				return false;
			}
		}
	}

	/**
	 * Get shipping costs.
	 *
	 * @access public
	 * @param integer $from
	 * @param integer $to
	 * @param float $weight
	 * @return array
	 */
	public function get_costs_pro( $type_ongkir, $from, $to, $weight, $courier = 'jne', $height = '10',
		$width = '10', $length = '10' ) {
		if( empty( $to ) )
			return;
			
		if( false !== get_transient('cl-ongkir-get_costs_pro'.$type_ongkir.'-'.$from.'-'.$to.'-'.$weight.'-'.$courier.'-'.$height.'-'.$width.'-'.$length) && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') && get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
			return get_transient('cl-ongkir-get_costs_pro'.$type_ongkir.'-'.$from.'-'.$to.'-'.$weight.'-'.$courier.'-'.$height.'-'.$width.'-'.$length);
		} else {
			$args = array(
				'origin'      		=> $from,
				"originType" 		=> 'city',
				'destination' 		=> $to,
				"destinationType" 	=> $type_ongkir,
				'weight'      		=> $weight,
				'courier'     		=> $courier,
				'height'			=> $height,
				'width'				=> $width,
				'length'			=> $length
			);
			$result = $this->cl_request_post( 'cost', $args );
			
			try {
				if( isset($result->rajaongkir) ) {
					if( $result->rajaongkir->status->code != 400 ) {
						$new_costs = object_to_array( $result->rajaongkir->results );
						set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
						set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
						if( !empty($new_costs) )
							set_transient('cl-ongkir-get_costs_pro'.$type_ongkir.'-'.$from.'-'.$to.'-'.$weight.'-'.$courier.'-'.$height.'-'.$width.'-'.$length, $new_costs, 12 * HOUR_IN_SECONDS);
					} else {
						$new_costs = '-';
					}
					return $new_costs;
				} else {
					return '-';
				}
			} catch ( Exception $e ) {
				var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
				return false;
			}
		}
	}

	/**
	 * Currency to IDR converter.
	 *
	 * @param string $woocommerce_currency, integer $amount
	 * @return integer
	 */
	public function convert_currency( $woocommerce_currency, $amount = 1 ) {
		if ( is_null($woocommerce_currency) || $woocommerce_currency == '' ) {
			try {
				$req = new Request(array(
					'server' => 'http://www.getexchangerates.com/api/convert/'
				));

				$uri = $amount . '/idr/'. strtolower( $woocommerce_currency ) ;

				$res = $req->get($uri, array());

				return $res->response;
			} catch (Exception $e) {
				return $amount;
			}
		}

		return false;
	}

	public function check_valid_apikey( $api_key ) {
		$result = self::$request->get('/city', array(
			'key' => $api_key,
			'province' =>15
		));

		try {
			if( isset($result->rajaongkir) && $result) {
				if($result->rajaongkir->status->code == 200){
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} catch ( Exception $e ) {
			var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Get list of city based on default country setting.
	 *
	 * @access public
	 * @param integer $woocommerce_default_country
	 * @return array
	 */
	public function get_cities( $woocommerce_default_country ) {
		// NOTE: check if province id have prefix ID:xx for the first install
		if( $this->choose == 'custom' && empty( $this->api_key ) ) {
			return '-';
		} else {
			if( false !== get_transient('cl-ongkir-get_cities'.$woocommerce_default_country) && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') &&
			get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
				return get_transient('cl-ongkir-get_cities'.$woocommerce_default_country);
			} else {
				if( $this->choose == 'custom' ){
					$result = self::$request->get('/city', array(
						'key' => $this->api_key,
						'province' => $this->convert_to_province_id( $woocommerce_default_country )
					));
				}
				else{
					$args = array(
						'key' => $this->api_key,
						'province' => $this->convert_to_province_id( $woocommerce_default_country )
					);
					$result = $this->cl_request_post( 'city', $args );
				}
				
				try {
					if( isset($result->rajaongkir) && $result != null ) {
						if($result->rajaongkir->status->code != 400){
							$cities = object_to_array( $result->rajaongkir->results );
							$simple_cities = array();
							if($cities){
								foreach ($cities as $city) {
									$simple_cities[$city['city_id']] = $city['type'] . ' ' . $city['city_name'];
								}
							}
							set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-get_cities'.$woocommerce_default_country, $simple_cities, 12 * HOUR_IN_SECONDS);
						} else {
							$simple_cities = '-';
						}
						return $simple_cities;
					} else {
						return '-';
					}

				} catch ( Exception $e ) {
					var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
					return false;
				}
			}
		}
	}

	/**
	 * Get city detail based on province
	 *
	 * @param int $rajaongkir_city_id
	 * @param int $rajaongkir_province_id
	 * @return string
	 */
	public function get_city( $rajaongkir_city_id, $rajaongkir_province_id ) {
		// NOTE: check if province id have prefix ID:xx for the first install
		if( false !== get_transient('cl-ongkir-get_city'.$rajaongkir_city_id.'-'.$rajaongkir_province_id) && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') &&
		get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
			return get_transient('cl-ongkir-get_city'.$rajaongkir_city_id.'-'.$rajaongkir_province_id);
		} else {
			// $result = self::$request->get('/city', array(
			// 	'key'      => $this->api_key,
			// 	'province' => $rajaongkir_province_id,
			// 	'id'       => $rajaongkir_city_id
			// ));
			if( $this->choose == 'custom' ){
				$result = self::$request->get('/city', array(
					'key' => $this->api_key,
					'province' => $rajaongkir_province_id
				));
			}
			else{
				$args = array(
					'key' => $this->api_key,
					'province' => $rajaongkir_province_id
				);
				$result = $this->cl_request_post( 'city', $args );
			}

			try {
				if( $result) {
					if( $result->rajaongkir->status->code == 200 ) {
					$city = object_to_array( $result->rajaongkir->results );
						if( $city ) {
							$city = $city['city_name'];
							set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-get_city'.$rajaongkir_city_id.'-'.$rajaongkir_province_id, $city, 12 * HOUR_IN_SECONDS);
						} else {
							$city = '-';
						}
					} else {
						$city = '-';
					}

					return $city;
				} else {
					return '-';
				}

			} catch ( Exception $e ) {
				var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
				return false;
			}
		}
	}

	/**
	 * Get province lists.
	 *
	 * @return array
	 */
	public function get_provinces() {
		// NOTE: check if province id have prefix ID:xx for the first install
		if( false !== get_transient('cl-ongkir-get_provinces') && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') &&
		get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
				return get_transient('cl-ongkir-get_city'.$rajaongkir_city_id.'-'.$rajaongkir_province_id);
		} else {
			$result = self::$request->get('/province', array(
				'key' => $this->api_key,
			));
			try {
				if( $result) {
					if( $result->rajaongkir->status->code != 400 ) {
						$provinces = object_to_array( $result->rajaongkir->results );

						$simple_provice = array();

						foreach ($provinces as $province) {
							$simple_provice[$province['province_id']] = $province['province'];
						}
						set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
						set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
						set_transient('cl-ongkir-get_provinces', $simple_provice, 12 * HOUR_IN_SECONDS);
					} else {
						$simple_provice = '-';
					}

					return $simple_provice;
				} else {
					return '-';
				}

			} catch ( Exception $e ) {
				var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
				return false;
			}
		}
	}

	/**
	 * Get subdistrict lists. [PRO VERSION]
	 *
	 * @return array
	 */
	public function get_subdistricts( $rajaongkir_sub_id, $rajaongkir_city_id ) {
		// NOTE: check if province id have prefix ID:xx for the first install
		if( false !== get_transient('cl-ongkir-get_subdistricts'.$rajaongkir_sub_id.'-'.$rajaongkir_city_id) && false !== get_transient('cl-ongkir-server-url') && false !== get_transient('cl-ongkir-apikey') &&
		get_transient('cl-ongkir-server-url') == $this->server && get_transient('cl-ongkir-apikey') == $this->api_key ){
			return get_transient('cl-ongkir-get_subdistricts'.$rajaongkir_sub_id.'-'.$rajaongkir_city_id);
		} else {
			$result = self::$request->get('/subdistrict', array(
				'key' => $this->api_key,
				'city' => $rajaongkir_city_id,
				'id'       => $rajaongkir_sub_id
			));

			try {
				if( $result) {
					if($result->rajaongkir->status->code != 400){
						if( get_option('woocommerce_type_account') == 'pro' ){
							$subdistricts = object_to_array( $result->rajaongkir->results );

							$simple_subdistrict = array();

							foreach ($subdistricts as $subdistrict) {
								if( isset($subdistrict['subdistrict_id']) && isset($subdistrict['subdistrict_name']) )
									$simple_subdistrict[$subdistrict['subdistrict_id']] = $subdistrict['subdistrict_name'];
							}
							set_transient('cl-ongkir-server-url', $this->server, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-apikey', $this->api_key, 12 * HOUR_IN_SECONDS);
							set_transient('cl-ongkir-get_subdistricts'.$rajaongkir_sub_id.'-'.$rajaongkir_city_id, $simple_subdistrict, 12 * HOUR_IN_SECONDS);
						}

					} else {
						$simple_subdistrict = '-';
					}

					return $simple_subdistrict;
				} else {
					return '-';
				}

			} catch ( Exception $e ) {
				var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
				return false;
			}
		}
	}

	public function get_sub( $woocommerce_city_id ) {
		// NOTE: check if province id have prefix ID:xx for the first install
		if( $this->choose == 'custom' ){
			$result = self::$request->get('/subdistrict', array(
				'key' => $this->api_key,
				'city' => $woocommerce_city_id
			));
		}
		else{
			$args = array(
				'key' => $this->api_key,
				'city' => $woocommerce_city_id
			);
			$result = $this->cl_request_post( 'subdistrict', $args );
		}

		try {
			if( $result) {
				if( $result->rajaongkir->status->code == 200 ) {
					$subdistricts = object_to_array( $result->rajaongkir->results );
					$simple_subdistricts = array();

					foreach ($subdistricts as $sub) {
						$simple_subdistricts[$sub['subdistrict_id']] = $sub['subdistrict_name'];
					}
				// echo '<pre>sc';
				// print_r( $simple_subdistricts );
				} else {
					$simple_subdistricts = '-';
				}

				return $simple_subdistricts;
			} else {
				return '-';
			}

		} catch ( Exception $e ) {
			var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
			return false;
		}
	}

	public function get_sub_auto( $q ) {
		// NOTE: check if province id have prefix ID:xx for the first install
		$args = array(
			'q' => $q
		);
		$result = $this->cl_request_post( 'subdistrict_auto', $args, 'https://ongkir.cepatlakoo.com/api/v1' );

		return $result;
	}

	public function cl_ongkir_check_license() {
		if( false !== get_transient('cl-ongkir-check_license') ){
			return get_transient('cl-ongkir-check_license');
		} else {
			$cl_valid = false;
			if (class_exists('EDD_Theme_Updater_Admin')) {
				$updater = new EDD_Theme_Updater_Admin;
				
				$updater = @$updater->check_license( true );
				$cl_valid = ( $updater['raw']->license == 'valid' ) ? true : false;
				$license = trim( get_option( sanitize_key('cepatlakoo') . '_license_key' ) );
				
				if( $cl_valid ){
					$args = array(
						'license' => $license,
						'domain' => home_url()
					);
					$result = $this->cl_request_post( 'license2', $args, 'https://ongkir.cepatlakoo.com/api/v1' );
					
					set_transient('cl-ongkir-check_license', ['cl' => $cl_valid, 'result' => $result, 'raw' => $updater['raw']], 12 * HOUR_IN_SECONDS);

					return ['cl' => $cl_valid, 'result' => $result, 'raw' => $updater['raw']];
				}
			}

			return ['cl' => $cl_valid];
		}
	}

	public function cl_ongkir_remove_domain($domain) {
		$license = trim( get_option( sanitize_key('cepatlakoo') . '_license_key' ) );
		delete_transient('cl-ongkir-check_license');
		$args = array(
			'license' => $license,
			'domain' => $domain
		);
		
		$result = $this->cl_request_post( 'remove_domain', $args, 'https://ongkir.cepatlakoo.com/api/v1' );
		return $result;
	}

	public function cl_ongkir_add_domain() {
		$license = trim( get_option( sanitize_key('cepatlakoo') . '_license_key' ) );
		delete_transient('cl-ongkir-check_license');
		$args = array(
			'license' => $license,
			'domain' => home_url()
		);
		
		$result = $this->cl_request_post( 'add_domain', $args, 'https://ongkir.cepatlakoo.com/api/v1' );
		
		return $result;
	}

	/**
	 * Convert woocommerce base_state to rajaongkir province_id
	 *
	 * @param  string $woocommerce_default_country
	 * @return integer
	 */
	public function convert_to_province_id( $woocommerce_base_state ) {
		$provinces = array(
			'AC' => 21,
			'SU' => 34,
			'SB' => 32,
			'RI' => 26,
			'KR' => 17,
			'JA' => 8,
			'SS' => 33,
			'BB' => 2,
			'BE' => 4,
			'LA' => 18,
			'JK' => 6,
			'JB' => 9,
			'BT' => 3,
			'JT' => 10,
			'JI' => 11,
			'YO' => 5,
			'BA' => 1,
			'NB' => 22,
			'NT' => 23,
			'KB' => 12,
			'KT' => 14,
			'KI' => 15,
			'KS' => 13,
			'KU' => 16,
			'SA' => 31,
			'ST' => 29,
			'SG' => 30,
			'SR' => 27,
			'SN' => 28,
			'GO' => 7,
			'MA' => 19,
			'MU' => 20,
			'PA' => 24,
			'PB' => 25
		);

		if( array_key_exists( $woocommerce_base_state, $provinces ) ) {
			return $provinces[$woocommerce_base_state];
		}
	}

	public function cl_check_connection($url){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 5,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		));

		$response = curl_exec($curl);
		$res = curl_error($curl);
		$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		curl_close($curl);
		
		if ( $http_code == 0 ) {
			return 3; // code 3 for RTO
		}
		else if ( $http_code != 200 && !empty($res) ){
			return $http_code;
		}
		else {
			return 0;
		}
	}

	public function cl_ongkir_tracking( $courier = 'jne', $resi ) {
		if( empty($this->api_key) )
			return 'empty_api_key';

		$result = self::$request->post('/waybill', array(
			'key' => $this->api_key,
			'courier' => $courier,
			'waybill' => $resi,
		));
		
		try {
			if( $result) {
				if( $result->rajaongkir->status->code == 200 ) {
					$res = array();
					$datas = object_to_array( $result->rajaongkir->result );
					
					$res = $datas;
				} else {
					$res = 'error';
				}

				return $res;
			} else {
				return 'error';
			}

		} catch ( Exception $e ) {
			var_dump( 'ERROR Catched! Message: ' . $e->getMessage() );
			return false;
		}
	}

	public function cl_request_post( $url, $args, $base_url = '' ){
		if( empty($url) || empty($args) )
			return;

		if( $this->method == 'wp' || ini_get('allow_url_fopen') == false ){
			$arg = array(
				'timeout' => 30,
				'headers' => array(
					'key'          => $this->api_key,
					'content-type' => 'application/x-www-form-urlencoded',
				),
				'body'    => $args,
			);

			if( !empty($base_url) ){
				$resp = wp_remote_post( $base_url.'/'.$url, $arg );
			}
			else{
				$resp = wp_remote_post( $this->server.'/'.$url, $arg );
			}
			
			if ( is_wp_error( $resp ) ) {
				return $resp;
			}
	
			$body = wp_remote_retrieve_body( $resp );
			
			if ( empty( $body ) ) {
				return new WP_Error( 'cl_ongkir_empty', __( 'API response is empty.', 'cl-ongkir' ) );
			}

			$data = json_decode( $body );	
			return $data;
		}
		else{
			$data = http_build_query($args);
			
			$opts = array('http' =>
				array(
					'method'  => 'POST',
					'header'  => "Content-type: application/x-www-form-urlencoded \r\n" .
								'key: '.$this->api_key,
					'content' => $data
				)
			);

			$context  = stream_context_create($opts);
			
			if( !empty($base_url) ){
				$result = @file_get_contents( $base_url.'/'.$url , false, $context);
			}
			else{
				$result = @file_get_contents( $this->server.'/'.$url , false, $context);
			}

			if ( empty( $result ) ) {
				return new WP_Error( 'cl_ongkir_empty', __( 'API response is empty.', 'cl-ongkir' ) );
			}

			if ( $result === false ) {
				return new WP_Error( 'cl_ongkir_error', __( 'API request failed.', 'cl-ongkir' ) );
			}
			
			return json_decode($result);
		}
	}

	public function cl_ongkir_decrypt($string, $action='decrypt') {
		$output = false;
		$encrypt_method = "AES-256-CBC";
		$secret_key = 'cepatlakoo-150-20190415';
		$secret_iv = 'XyjBp7fFyt';
		// hash
		$key = hash('sha256', $secret_key);
		
		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
		$iv = substr(hash('sha256', $secret_iv), 0, 16);
		if ( $action == 'encrypt' ) {
			$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
			$output = base64_encode($output);
		} else if( $action == 'decrypt' ) {
			$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
		}
		return $output;
	}
}