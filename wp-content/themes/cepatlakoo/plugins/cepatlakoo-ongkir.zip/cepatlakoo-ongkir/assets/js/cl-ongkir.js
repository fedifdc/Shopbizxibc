/*!
 * cl_ongkir.js v1.3.1
 * Copyright 2014, eezhal92
 *
 * Freely distributable under the MIT license.
 * this script using jQuery
 *
 * http://eezhal92.com
 */
(function($) {
	//BIlling State = Province
	var user_billing_subdistrict = cl_ongkirAjax.billing_subdistrict;
	var user_shipping_subdistrict = cl_ongkirAjax.shipping_subdistrict;
	var user_billing_state = $('#billing_state').val();
	var user_shipping_state = $('#shipping_state').val();

	var curRequest = {};
	var diffShipping = ( $('.woocommerce-checkout').length > 0 ) ? $('#ship-to-different-address input:checkbox:checked').length : 1;
	var is_cart = ( $('.woocommerce-cart-form').length > 0 ) ? true : false;
	var calc_state = $('#billing_state').find('option:selected').val();
	var calc_city = cl_ongkirAjax.billing_city;
	var calc_sub = cl_ongkirAjax.billing_subdistrict;
	
	if( ! diffShipping || is_cart){
		if( user_billing_state ) {
			getCities('#billing_city', user_billing_state, cl_ongkirAjax.billing_city );
		}
	}else if( user_shipping_state ) {
		getCities('#billing_city', user_billing_state, cl_ongkirAjax.billing_city );
		getCities('#shipping_city', user_shipping_state, cl_ongkirAjax.shipping_city );
	}

	$(document).on('click', '.woocommerce-shipping-calculator button[name=calc_shipping]', function() {
		calc_state = $('#billing_state').find('option:selected').val();
		calc_city = $('#billing_city').find('option:selected').val();
		calc_sub = $('#billing_subdistrict').find('option:selected').val();
	});

	$(document).on('click', '.woocommerce-shipping-calculator .shipping-calculator-button', function() {
		var b_state_id = calc_state;
		$('#billing_city').attr('disabled', true);
		$('#billing_city').select2();
		$('#billing_city').attr('data-selected', calc_city);
		$('select#billing_city').css('background', 'rgba(0,0,0,0.04)');
		
		$('#billing_subdistrict').select2();
		$('#billing_subdistrict').attr('data-selected', calc_sub);

		
		if( b_state_id ) {
			// $('#billing_city').empty();
			$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#billing_city');
			getCities( '#billing_city', b_state_id, calc_city);
		}
	});
	
	//City Billing on Change : ALL PACKAGE
	$(document).on('change', '#calc_shipping_state', function() {
		var b_state_id = $(this).find('option:selected').val();
		$('#calc_shipping_city').attr('disabled', true);
		$('select#calc_shipping_city').css('background', 'rgba(0,0,0,0.04)');

		if( b_state_id ) {
			$('#calc_shipping_city').empty();
			$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#calc_shipping_city');
			getCities( '#calc_shipping_city', b_state_id, cl_ongkirAjax.billing_city);
		}
	});

	//City Billing on Change : ALL PACKAGE
	$(document).on('change', '#billing_state', function() {
		var b_state_id = $(this).find('option:selected').val();
		$('#billing_city').attr('disabled', true);
		$('select#billing_city').css('background', 'rgba(0,0,0,0.04)');
		$('#cl_bill_state_name').val( jQuery('#billing_state').select2('data')[0].text );

		if( b_state_id ) {
			$('#billing_city').empty();
			$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#billing_city');
			$('#billing_subdistrict').empty();
			$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#billing_subdistrict');
			getCities( '#billing_city', b_state_id, cl_ongkirAjax.billing_city);
		}
	});

	//City Billing on Change : ALL PACKAGE
	$(document).on('change', '#shipping_state', function() {
		var diffShipping = ( $('.woocommerce-checkout').length > 0 ) ? $('#ship-to-different-address input:checkbox:checked').length : 1;

		if ( diffShipping == 1 ){
			var s_state_id = $(this).find('option:selected').val();
			$('#shipping_city').attr('disabled', true);
			$('select#shipping_city').css('background', 'rgba(0,0,0,0.04)');

			if( s_state_id ) {
				$('#shipping_city').empty();
				$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#shipping_city');
				$('#shipping_subdistrict').empty();
				$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#shipping_subdistrict');
				getCities( '#shipping_city', s_state_id, cl_ongkirAjax.shipping_city);
			}
		}
	});

	//Subdistrict Billing on Change : PRO BASIC
	$(document).on('change', '#billing_city', function() {
		var b_city_id = $(this).find('option:selected').val();
		$('#billing_subdistrict').attr("disabled", false);
		$('select#billing_subdistrict').css('background', 'rgba(0,0,0,0.0)');
		$('#cl_bill_city_name').val( $(this).find('option:selected').html() );
		
		if( b_city_id ) {
			$('#billing_subdistrict').empty();
			$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#billing_subdistrict');
			getSubdistrict( '#billing_subdistrict', b_city_id, null);
		}
	});

	//Subdistrict Shippinh on Change : PRO BASIC
	$(document).on('change', '#shipping_city', function() {
		var diffShipping = ( $('.woocommerce-checkout').length > 0 ) ? $('#ship-to-different-address input:checkbox:checked').length : 1;
		
		if ( diffShipping == 1 ){
			var s_city_id = $(this).find('option:selected').val();
			$('#shipping_city').attr("disabled", false);
			$('select#shipping_city').css('background', 'rgba(0,0,0,0.0)');
			$('#cl_ship_city_name').val( $(this).find('option:selected').html() );

			if( s_city_id ) {
				$('#shipping_subdistrict').empty();
				$("<option/>",{ value:'loading', text:'Loading...' }).appendTo('#shipping_subdistrict');
				getSubdistrict( '#shipping_subdistrict', s_city_id, null);
			}
		}
	});

	// Trigger Subdistrict
	$(document).on('change', '#billing_subdistrict', function() {
		if(cl_ongkirAjax.single_subdistrict == 'yes' ){
			$('#billing_city').val( jQuery('#billing_subdistrict').select2('data')[0].city );
			$('#billing_state').val( jQuery('#billing_subdistrict').select2('data')[0].state );
			$('#cl_bill_subdistrict_name').val( jQuery('#billing_subdistrict').select2('data')[0].subdistrict );
			$('#cl_bill_city_name').val( jQuery('#billing_subdistrict').select2('data')[0].city );
		}
		else{
			var s_city_id = $(this).find('option:selected').val();
			$('#shipping_city').attr("disabled", false);
			$('select#shipping_city').css('background', 'rgba(0,0,0,0.0)');
			$('#cl_bill_subdistrict_name').val( $(this).find('option:selected').html() );
	
			if( s_city_id ) {
				getSubdistrict( '#billing_subdistrict', null, s_city_id);
			}
		}

	});

	// Trigger Subdistrict
	$(document).on('change', '#shipping_subdistrict', function() {
		if(cl_ongkirAjax.single_subdistrict == 'yes' ){
			$('#shipping_city').val( jQuery('#shipping_subdistrict').select2('data')[0].city );
			$('#shipping_state').val( jQuery('#shipping_subdistrict').select2('data')[0].state );
			$('#cl_ship_city_name').val( jQuery('#shipping_subdistrict').select2('data')[0].city );
			$('#cl_ship_subdistrict_name').val( jQuery('#shipping_subdistrict').select2('data')[0].subdistrict );
		}
		else{
			var diffShipping = ( $('.woocommerce-checkout').length > 0 ) ? $('#ship-to-different-address input:checkbox:checked').length : 1;
			
			if ( diffShipping == 1 ){
				var s_city_id = $(this).find('option:selected').val();
				$('#cl_ship_subdistrict_name').val( $(this).find('option:selected').html() );
	
				$('#shipping_city').attr("disabled", false);
				$('select#shipping_city').css('background', 'rgba(0,0,0,0.0)');
	
				if( s_city_id ) {
					getSubdistrict( '#shipping_subdistrict', null, s_city_id);
				}
			}
		}
	});

	// Request Cities : ALL PACKAGE
	function getCities( city_element, user_state_id, user_city_id) {
		curRequest[city_element] = $.ajax({
	      	url: cl_ongkirAjax.ajax_url,
	      	type: 'get',
	      	data: {
				'action': 'get_cities',
				'nonce': cl_ongkirAjax.nonce,
				'state': user_state_id
			},
			beforeSend : function()    {
	            if(curRequest[city_element] != null) {
	                curRequest[city_element].abort();
	            }
	        },
			  success: function( data ) { // return string
				
				data = jQuery.parseJSON(data);
				if(data == '-'){
					alert(cl_ongkirAjax.error_msg);
					jQuery('#place_order').prop('disabled', true);
				}
				else{
					$(city_element).empty();
					$.each( data, function (city_id, city_name) {

						if( $(city_element).attr('data-selected') != 0 && $(city_element).attr('data-selected') == city_id ){
							$("<option/>",{ value:city_id, text:city_name, selected:'selected' }).appendTo(city_element);
						}
						else{
							$("<option/>",{ value:city_id, text:city_name}).appendTo(city_element);
						}

				  });
				  
				  $(city_element).attr('disabled', false);
				  $('select#billing_city').css('background', 'rgba(0,0,0,0)');
				  $('select#shipping_city').css('background', 'rgba(0,0,0,0)');
				  $(city_element).css('background', 'rgba(0,0,0,0)');
				  $(city_element).trigger("change");
				}
	      	}
	    });
	}

	// Request Subdistric : PRO & BASIC ONLY
	function getSubdistrict( element, user_city_id, user_subdistrict_id) {
		// console.log(cl_ongkirAjax.type);
		if(cl_ongkirAjax.type == 'pro'){
			curRequest[element] = $.ajax({
				  url: cl_ongkirAjax.ajax_url,
				  type: 'get',
				  data: {
					'action': 'get_subdistrict',
					'city': user_city_id,
					'sdistrict' : user_subdistrict_id,
					'nonce': cl_ongkirAjax.nonce,
				},
				beforeSend : function()    {
					if(curRequest[element] != null) {
						curRequest[element].abort();
					}
				},
				  success: function( data ) { // return string
					
					if( user_subdistrict_id === '' || user_subdistrict_id === null ){
						data = jQuery.parseJSON(data);
						$(element).empty();
						$.each( data, function (subdistrict_id, subdistrict_name) {
							
							if( $(element).attr('data-selected') != 0 && $(element).attr('data-selected') == subdistrict_id ){
								$("<option/>",{ value:subdistrict_id, text:subdistrict_name, selected:'selected' }).appendTo(element);
							}
							else{
								$("<option/>",{ value:subdistrict_id, text:subdistrict_name }).appendTo(element);
							}
					  });
					  
					  $(element).attr('disabled', false);
	  
					  $(element).css('background', 'rgba(0,0,0,0)');

					  $(element).trigger('change');
					}
				  }
			});
		}
	}

	$(window).resize(function() {
		$('.select2').css('width', "100%");
	});
	
    $(document).on('click', "#ship-to-different-address-checkbox", function() {
		if( $('#ship-to-different-address input:checkbox:checked').length > 0 && $('#shipping_city option').first().val() === '' ){
			getCities('#shipping_city', user_shipping_state, cl_ongkirAjax.shipping_city );
		}
	});

	// jQuery('#billing_state_field').after(jQuery('#billing_city_field'));
	// jQuery('#billing_city_field').after(jQuery('#billing_subdistrict_field'));
})(jQuery);

jQuery(document).ready(function( $ ) {
	cl_ongkir_init();

	$('select#billing_city[disabled=disabled]').css('background', 'rgba(0,0,0,0.04)');
	$('select#shipping_city[disabled=disabled]').css('background', 'rgba(0,0,0,0.04)');
	$('select#billing_subdistrict[disabled=disabled]').css('background', 'rgba(0,0,0,0.04)');
	$('select#shipping_subdistrict[disabled=disabled]').css('background', 'rgba(0,0,0,0.04)');
	
	removeFieldsClass();
	
	// Page updated only when city fields is changed : OK
    function removeFieldsClass() {
		$('#billing_address_1_field').removeClass('address-field ');
		$('#billing_state_field').removeClass('address-field ');
		$('#billing_postcode_field').removeClass('address-field ');
		$('#shipping_address_1_field').removeClass('address-field ');
		$('#shipping_state_field').removeClass('address-field ');
		$('#shipping_postcode_field').removeClass('address-field ');
	}

	function cl_ongkir_init(){
		// initialization	
		if(cl_ongkirAjax.single_subdistrict == 'yes' ){
			$('#billing_subdistrict').select2({
				ajax: {
					url: cl_ongkirAjax.ajax_url,
					dataType: 'json',
					data: function (params) {
						var query = {
						'q': params.term,
						'action': 'get_subdistrict_auto',
						'nonce': cl_ongkirAjax.nonce
						}

						return query;
					},
					delay: 250,
					processResults: function (data) {
						return {
							results: $.map(data, function (obj) {
								return { 
										id: obj.id, 
										text: obj.text, 
										subdistrict: obj.subdistrict, 
										city: obj.city, 
										state: obj.state
								};
							})
						}
					},
					cache: true
				},
				minimumInputLength: 3,
				language: {
					inputTooShort: function() {
						return cl_ongkirAjax.msg_default_subdistrict;
					}
				}
			});

			$('#shipping_subdistrict').select2({
				ajax: {
					url: cl_ongkirAjax.ajax_url,
					dataType: 'json',
					data: function (params) {
						var query = {
						'q': params.term,
						'action': 'get_subdistrict_auto',
						'nonce': cl_ongkirAjax.nonce
						}

						return query;
					},
					delay: 250,
					processResults: function (data) {
						return {
							results: $.map(data, function (obj) {
								return { 
										id: obj.id, 
										text: obj.text, 
										subdistrict: obj.subdistrict, 
										city: obj.city, 
										state: obj.state
								};
							})
						}
					},
					cache: true
				},
				minimumInputLength: 3,
				language: {
					inputTooShort: function() {
						return cl_ongkirAjax.msg_default_subdistrict;
					}
				}
			});

			$('#cl_billing_state').addClass('state_select');
			$('#cl_billing_state').attr('id','billing_state');
			$('#cl_shipping_state').addClass('state_select');
			$('#cl_shipping_state').attr('id','shipping_state');
		}
		else{
			$('#billing_subdistrict').attr('disabled', true).select2();
			$('#shipping_subdistrict').attr('disabled', true).select2();
			$('#billing_city').attr('disabled', true).select2();
			$('#shipping_city').attr('disabled', true).select2();
		}
	}
});
