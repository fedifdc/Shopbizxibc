(function($) {
    'use strict';
    $(document).ready(function () {

    	$('input[name="woocommerce_rajaongkir_api_key"]').closest('tr').css('display','none');
    	$('input[name="woocommerce_type_account"]').closest('tr').css('display','none');
        $('.cl-service-parent').hide();
        $('.cl-service-row').hide();
        
        $.each( $('#woocommerce_cl_ongkir_shipping_courier').val(), function( i, val ){
            $('.cl-service-parent').show();

            if( val == 'all' && $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'pro' ){
                $('.cl-service-row').show();
            }
            else if ( val == 'all' && $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'basic' ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki, .cl-service-row.pcp, .cl-service-row.esl, .cl-service-row.rpx').show();
            }
            else if ( val == 'all' && $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'starter' ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki').show();
            }
            else{
                $('.cl-service-row.'+val).show();
            }
        });

        $.each( $('.cl-ongkir-custom-api'), function(){
            if( $('.cl-choose-key:checked').val() != 'custom' ){
                $('.cl-ongkir-custom-api').parents('tr').hide();
            }
        });

        $( ".cl-ongkir-custom-api-type" ).trigger( "change" );
    });

    $(document).on('change', '#woocommerce_cl_ongkir_shipping_courier', function() {
        $('.cl-service-row').hide();
        if( $(this).val() === null ){
            $('.cl-service-parent').hide();
        }
        
        $.each( $('#woocommerce_cl_ongkir_shipping_courier').val(), function( i, val ){
            $('.cl-service-parent').show();
            
            if( val == 'all' && ( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'pro' || $('.cl_ongkir_shipping_type_ongkir').val() == 'pro' ) ){
                $('.cl-service-row').show();
            }
            else if ( val == 'all' && ( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'basic' || $('.cl_ongkir_shipping_type_ongkir').val() == 'basic' ) ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki, .cl-service-row.pcp, .cl-service-row.esl, .cl-service-row.rpx').show();
            }
            else if ( val == 'all' && ( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'starter' || $('.cl_ongkir_shipping_type_ongkir').val() == 'starter' ) ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki').show();
            }
            else{
                $('.cl-service-row.'+val).show();
            }
        });
    });

    $(document).on('click', '.wc-shipping-zone-method-settings', function() {
        $('.cl-service-parent').hide();
        $('.cl-service-row').hide();
        
        // $.each( $('#woocommerce_cl_ongkir_shipping_courier').val(), function( i, val ){
            
            $('.cl-service-parent').show();

            if( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'pro' || $('.cl_ongkir_shipping_type_ongkir').val() == 'pro' ){
                $('.cl-service-row').show();
            }
            else if ( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'basic' || $('.cl_ongkir_shipping_type_ongkir').val() == 'basic' ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki, .cl-service-row.pcp, .cl-service-row.esl, .cl-service-row.rpx').show();
            }
            else if ( $('#woocommerce_cl_ongkir_shipping_type_ongkir').val() == 'starter' || $('.cl_ongkir_shipping_type_ongkir').val() == 'starter' ){
                $('.cl-service-row.jne, .cl-service-row.pos, .cl-service-row.tiki').show();
            }
            else{
                // $('.cl-service-row.'+val).show();
            }
        // });
    });

    $(document).on('click', '.cl-ongkir-select-all', function() {
        $('.cl-ongkir-zones-services input[type="checkbox"]').prop('checked', true);
        return false;
    });

    $(document).on('click', '.cl-ongkir-deselect-all', function() {
        $('.cl-ongkir-zones-services input[type="checkbox"]').prop('checked', false);
        return false;
    });

    $(document).on('change', '.cl-choose-key', function() {
        if( $(this).val() === 'custom' ){
            $('.cl-ongkir-custom-api').parents('tr').show();
        }
        else{
            $('.cl-ongkir-custom-api').parents('tr').hide();
            jQuery('#woocommerce_cl_ongkir_shipping_cl_single_subdistrict').parents('tr').show();
        }
        $( ".cl-ongkir-custom-api-type" ).trigger( "change" );
    });

    $(document).on('change', '.cl-ongkir-custom-api-type', function() {
        if( ($(this).val() != 'pro') && ($('.cl-choose-key:checked').val() === 'custom') ){
            $('#woocommerce_cl_ongkir_shipping_cl_single_subdistrict').attr('checked', false);
            jQuery('#woocommerce_cl_ongkir_shipping_cl_single_subdistrict').parents('tr').hide();
        }
        else{
            jQuery('#woocommerce_cl_ongkir_shipping_cl_single_subdistrict').parents('tr').show();
        }
    });

    $(document).on('click', '.cl-ongkir-remove-domain', function() {
        if( $(this).attr('data-domain') != ''){
            var that = $(this);
            $.ajax({
                url: cl_ongkirAjax.ajax_url,
                type: 'get',
                data: {
                    'action': 'cl_ongkir_remove_domain',
					'nonce': cl_ongkirAjax.nonce,
                    'domain': $(this).attr('data-domain'),
                },
                success: function( data ) { // return string
                    data = jQuery.parseJSON(data);
                    if( data.status == true ){
                        $(that).parents('p').remove();
                        location.reload();
                    }
                    else
                        alert('system error, please contact our cs');
                }
            });
        }
        else{
            alert('Domain cant empty');
        }
        
        return false;
    });

    $(document).on('click', '.cl-ongkir-register-domain', function() {
        $(this).attr('disabled', true);
        $.ajax({
            url: cl_ongkirAjax.ajax_url,
            type: 'get',
            data: {
                'action': 'cl_ongkir_register_domain',
                'nonce': cl_ongkirAjax.nonce,
            },
            success: function( data ) { // return string
                data = jQuery.parseJSON(data);
                if( data.status == true )
                    location.reload();
                else if( data.status == false && data.msg != '' )
                    alert(data.msg+': '+data.domain);
                else
                    alert('system error, please contact our cs');
            }
        });
        $(this).attr('disabled', false);
        return false;
    });
    
    $(document).on('change', '#cl-ongkir-jne-reg', function() {
        if( $('#cl-ongkir-jne-reg').is(':checked') ){
            $('#cl-ongkir-jne-ctc').prop('checked', true);
        }
        else{
            $('#cl-ongkir-jne-ctc').prop('checked', false);
        }
    });
    
    $(document).on('change', '#cl-ongkir-jne-yes', function() {
        if( $('#cl-ongkir-jne-yes').is(':checked') ){
            $('#cl-ongkir-jne-ctcyes').prop('checked', true);
        }
        else{
            $('#cl-ongkir-jne-ctcyes').prop('checked', false);
        }
    });
    
    $(document).on('click', '.wc-shipping-zone-method-settings', function() {
        if( $('.cl-ongkir-add-fee').length > 0 )
            $( ".cl-ongkir-add-fee" ).trigger( "change" );

        if( $('#cl-ongkir-free-status').length > 0 ){
            $( '#cl-ongkir-free-status' ).trigger( "change" );
            
            $('.cl-number-only').keyup(function() {
                var numbers = $(this).val();
                $(this).val(numbers.replace(/\D/, ''));
            });
        }
    });

    $(document).on('change', '.cl-ongkir-add-fee', function() {
        if( $(this).val() == 'none' ){
            jQuery('.cl-ongkir-add-fee-fixed, .cl-ongkir-add-fee-percent').hide();
        }
        else if( $(this).val() == 'fixed' ) {
            jQuery('.cl-ongkir-add-fee-fixed, .cl-ongkir-add-fee-percent').hide();
            jQuery('.cl-ongkir-add-fee-fixed').show();
        }
        else if( $(this).val() == 'percent' ) {
            jQuery('.cl-ongkir-add-fee-fixed, .cl-ongkir-add-fee-percent').hide();
            jQuery('.cl-ongkir-add-fee-percent').show();
        }
    });

    $(document).on('change', '#cl-ongkir-free-status', function() {
        $( '.cl-ongkir-free-type' ).trigger( "change" );
        if( $(this).prop('checked') == true ){
            jQuery('.cl-ongkir-fee-type, .cl-ongkir-free-min-amount, .cl-ongkir-free-ignore, .cl-ongkir-free-hide-reg').show();
        }
        else {
            jQuery('.cl-ongkir-fee-type, .cl-ongkir-free-min-amount, .cl-ongkir-free-ignore, .cl-ongkir-free-hide-reg').hide();
        }
    });

    $(document).on('change', '.cl-ongkir-free-type', function() {
        if( $(this).val() == 'none' || $(this).val() == 'coupon' ){
            jQuery('.cl-ongkir-free-min-amount, .cl-ongkir-free-ignore').hide();
        }
        else {
            jQuery('.cl-ongkir-free-min-amount, .cl-ongkir-free-ignore').show();
        }
    });
})(jQuery);
