<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class CepatLakoo_Marketplace_Links_Widget_Elementor extends Widget_Base {

	public function get_name() {
		return 'cepatlakoo-marketplace-link';
	}

	public function get_title() {
		return esc_html__( 'CL - Marketplace Links', 'cepatlakoo' );
	}

	public function get_icon() {
		// Icon name from the Elementor font file, as per http://dtbaker.net/web-development/creating-your-own-custom-elementor-widgets/
		return 'eicon-button';
	}

	protected function register_controls() {
		global $cl_options;

		$this->start_controls_section(
			'cepatlakoo_section_name',
			[
				'label' => esc_html__( 'CL - Marketplace Links', 'cepatlakoo' ),
			]
		);

		$this->add_control(
			'cepatlakoo_marketplace_link_info',
			[
				'label' => esc_html__( 'Information', 'cepatlakoo' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Widget CL- Marketplace Link digunakan untuk menampilkan button marketplace link yang telah diatur di edit products.', 'cepatlakoo' ),
				'content_classes' => 'clel-notice',
			]
		);

		if( empty(get_post_meta( get_the_ID(), '_cl_marketplace_link', true )) ){
			$this->add_control(
				'cepatlakoo_empty_marketplace_link_info',
				[
					'label' => esc_html__( 'Empty Link', 'cepatlakoo' ),
					'type' => \Elementor\Controls_Manager::RAW_HTML,
					'raw' => esc_html__( 'Marketplace Link masih kosong, silahkan edit marketplace link di halaman edit produk.', 'cepatlakoo' ),
					'content_classes' => 'clel-error',
				]
			);
		}

		$this->end_controls_tab();
	}

	protected function render() {
		// Reference : https://github.com/pojome/elementor/issues/738
		// get our input from the widget settings.
		$marketplace_enabled = get_option( 'cl_enable_salesbooster_marketplace' );
	
		if ( $marketplace_enabled != 'yes' ) {
			return;
		}

		global $cl_options;
		$options = get_option('cl_salesbooster_setting');
		$pixel_active = false;
		if( !empty( $cl_options['cepatlakoo_facebook_pixel_id'] ) ? $cl_options['cepatlakoo_facebook_pixel_id'] : '' ){
			if( isset($options['cl-marketplace-fb-pixel']) ){
				$fb_event = ($options['cl-marketplace-fb-pixel'] == 'Custom') ? $options['cl-marketplace-fb-pixel-custom'] : $options['cl-marketplace-fb-pixel'] ;
				$pixel_active = true;
			}
			else{
				$pixel_active = false;
			}
		}
		$market = isset( $options['cl-marketplace'] ) ? $options['cl-marketplace'] : '';
		$links = get_post_meta( get_the_ID(), '_cl_marketplace_link', true ); ?>

		<div class="cl_marketplace">
			<?php if($links) : ?>
				<?php if( isset($options['cl-marketplace-info']) && !empty($options['cl-marketplace-info']) ) : ?>
					<p class="contact-message"><?php echo $options['cl-marketplace-info']; ?></p>
				<?php endif; ?>
				
				<?php foreach($links as $link) : ?>
					<a <?php echo ( $pixel_active ) ? 'fb-pixel="'.$fb_event.'"' : ''; ?> href="<?php echo $link['link']; ?>" class="<?php echo $link['type']; ?> cl-marketplace-button" target="<?php echo ($link['tab'] == 'true') ? '_blank': '_self' ?>">
						<img src="<?php echo $market[$link['type']]['logo']; ?>">
					</a>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {}

}
Plugin::instance()->widgets_manager->register( new CepatLakoo_Marketplace_Links_Widget_Elementor() );
