<!DOCTYPE html>
<html>
<head>
  <script src="<?php echo plugins_url('jquery-1.11.3.min.js', __FILE__) ?>"></script>
  <link rel="stylesheet" href="<?php echo plugins_url('scan.css', __FILE__) ?>">
</head>
<body>
  <!-- <div><?php //_e('Barcode result:', 'cl-input-resi'); ?> <span id="dbr"></span></div> -->
  
  <div class="select">
    <label for="videoSource"><?php _e('Camera:', 'cl-input-resi'); ?> </label><select id="videoSource"></select>
  </div>
  <!-- <button id="go" class="button"><?php _e('Re Scan', 'cl-input-resi'); ?></button> -->
  <div class="video-holder">
    <video muted autoplay id="video" playsinline="true" style="height:210px; width:230px;"></video>
    <!-- <canvas id="pcCanvas" width="240" height="240" style="display: none; float: bottom;"></canvas>
    <canvas id="mobileCanvas" width="240" height="320" style="display: none; float: bottom;"></canvas> -->
  </div>
</body>

<script async src="<?php echo plugins_url('zxing.js', __FILE__) ?>"></script>
<script src="<?php echo plugins_url('video.min.js', __FILE__) ?>"></script>
