(function($) {
    'use strict';
    $(document).ready(function () {
        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        };

        if(getUrlParameter('page') == 'cepatlakoo_input_resi'){
            $('.form-table').repeater({
                defaultValues: {
                    'text-input': '',
                },
                show: function () {
                    $(this).slideDown();
                },
                hide: function (deleteElement) {
                    $(this).slideUp(deleteElement);
                }
            });

            var dataExp = $('input[name="cepatlakoo_ekspedisi"]').val().split(",");
            $('.data-item:first').remove();
            $.each(dataExp,function(i){
               $( '[data-repeater-list="data-ekspedisi"]' ).append( '<div data-repeater-item class="data-item"><input class="regular-text" type="text" name="data-ekspedisi['+ i +'][text-input]" value="'+ dataExp[i] +'"> <button class="button button-secondary button-delete" data-repeater-delete="" type="button"><span class="dashicons dashicons-trash"></span> '+ _cl_inputresi.translation +'</button></div>');
            });

            $("form").submit(function(e){
                console.log($("form").serialize());
                var dataItem = [];
                for (var i = 0; i < $('.data-item').length; i++) {
                    if(!$('input[name="data-ekspedisi['+ i +'][text-input]"]').val()){
                        $('input[name="data-ekspedisi['+ i +'][text-input]"]').siblings("[data-repeater-delete]").trigger('click');
                    }else{
                        dataItem.push($('input[name="data-ekspedisi['+ i +'][text-input]"]').val());
                    }
                }
                $('input[name="cepatlakoo_ekspedisi"]').val(dataItem.toString());
            });
        }

    });

    $(document).on('click', '#cl-input-resi-scan-button', function(){
        var scan_url = $( this ).attr('data-url');
        if ( $('#cl-input-resi-scan-area iframe').attr('src') == '' ){
            $('#cl-input-resi-scan-area iframe').attr('src', scan_url);
        }

        $('#cl-input-resi-scan-area').show();
        return false;
    });
})(jQuery);
